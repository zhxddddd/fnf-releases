// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../database.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(profilesStream)
final profilesStreamProvider = ProfilesStreamProvider._();

final class ProfilesStreamProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<Profile>>,
          List<Profile>,
          Stream<List<Profile>>
        >
    with $FutureModifier<List<Profile>>, $StreamProvider<List<Profile>> {
  ProfilesStreamProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'profilesStreamProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$profilesStreamHash();

  @$internal
  @override
  $StreamProviderElement<List<Profile>> $createElement(
    $ProviderPointer pointer,
  ) => $StreamProviderElement(pointer);

  @override
  Stream<List<Profile>> create(Ref ref) {
    return profilesStream(ref);
  }
}

String _$profilesStreamHash() => r'ea944e081294567f0f63286e95e4e66cdc650383';

@ProviderFor(customGroupNames)
final customGroupNamesProvider = CustomGroupNamesProvider._();

final class CustomGroupNamesProvider
    extends
        $FunctionalProvider<
          AsyncValue<Set<String>>,
          Set<String>,
          Stream<Set<String>>
        >
    with $FutureModifier<Set<String>>, $StreamProvider<Set<String>> {
  CustomGroupNamesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'customGroupNamesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$customGroupNamesHash();

  @$internal
  @override
  $StreamProviderElement<Set<String>> $createElement(
    $ProviderPointer pointer,
  ) => $StreamProviderElement(pointer);

  @override
  Stream<Set<String>> create(Ref ref) {
    return customGroupNames(ref);
  }
}

String _$customGroupNamesHash() => r'9d3d1a6b57aeee7b4cf34afd20e28336484a5de7';

@ProviderFor(Profiles)
final profilesProvider = ProfilesProvider._();

final class ProfilesProvider
    extends $NotifierProvider<Profiles, List<Profile>> {
  ProfilesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'profilesProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$profilesHash();

  @$internal
  @override
  Profiles create() => Profiles();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(List<Profile> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<List<Profile>>(value),
    );
  }
}

String _$profilesHash() => r'0f7e5be5f04f855ed2ad3dc969e95b82eed7c2a5';

abstract class _$Profiles extends $Notifier<List<Profile>> {
  List<Profile> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<List<Profile>, List<Profile>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<List<Profile>, List<Profile>>,
              List<Profile>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(Scripts)
final scriptsProvider = ScriptsProvider._();

final class ScriptsProvider
    extends $StreamNotifierProvider<Scripts, List<Script>> {
  ScriptsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'scriptsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$scriptsHash();

  @$internal
  @override
  Scripts create() => Scripts();
}

String _$scriptsHash() => r'f88f4a2c9960c884fbc2317f754f0f968340ade2';

abstract class _$Scripts extends $StreamNotifier<List<Script>> {
  Stream<List<Script>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<List<Script>>, List<Script>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<Script>>, List<Script>>,
              AsyncValue<List<Script>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(MitmModules)
final mitmModulesProvider = MitmModulesProvider._();

final class MitmModulesProvider
    extends $StreamNotifierProvider<MitmModules, List<MitmModule>> {
  MitmModulesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'mitmModulesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$mitmModulesHash();

  @$internal
  @override
  MitmModules create() => MitmModules();
}

String _$mitmModulesHash() => r'f7ff19a7e8b913c8987f0176eadc80222882e633';

abstract class _$MitmModules extends $StreamNotifier<List<MitmModule>> {
  Stream<List<MitmModule>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<MitmModule>>, List<MitmModule>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<MitmModule>>, List<MitmModule>>,
              AsyncValue<List<MitmModule>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(ClashProviders)
final clashProvidersProvider = ClashProvidersProvider._();

final class ClashProvidersProvider
    extends $StreamNotifierProvider<ClashProviders, List<ClashProvider>> {
  ClashProvidersProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'clashProvidersProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$clashProvidersHash();

  @$internal
  @override
  ClashProviders create() => ClashProviders();
}

String _$clashProvidersHash() => r'00588fa9c7300d3319d97d61962e898d29497188';

abstract class _$ClashProviders extends $StreamNotifier<List<ClashProvider>> {
  Stream<List<ClashProvider>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<ClashProvider>>, List<ClashProvider>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<ClashProvider>>, List<ClashProvider>>,
              AsyncValue<List<ClashProvider>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(IconSets)
final iconSetsProvider = IconSetsProvider._();

final class IconSetsProvider
    extends $StreamNotifierProvider<IconSets, List<IconSet>> {
  IconSetsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'iconSetsProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$iconSetsHash();

  @$internal
  @override
  IconSets create() => IconSets();
}

String _$iconSetsHash() => r'156404c618b212fea961e9e108b3db1d3e17e2d1';

abstract class _$IconSets extends $StreamNotifier<List<IconSet>> {
  Stream<List<IconSet>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<List<IconSet>>, List<IconSet>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<IconSet>>, List<IconSet>>,
              AsyncValue<List<IconSet>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(GlobalRules)
final globalRulesProvider = GlobalRulesProvider._();

final class GlobalRulesProvider
    extends $StreamNotifierProvider<GlobalRules, List<Rule>> {
  GlobalRulesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'globalRulesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$globalRulesHash();

  @$internal
  @override
  GlobalRules create() => GlobalRules();
}

String _$globalRulesHash() => r'44b89f90ca1499f7ea7a0344206fe16d38deeffb';

abstract class _$GlobalRules extends $StreamNotifier<List<Rule>> {
  Stream<List<Rule>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<List<Rule>>, List<Rule>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<Rule>>, List<Rule>>,
              AsyncValue<List<Rule>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(profileGroupsCount)
final profileGroupsCountProvider = ProfileGroupsCountFamily._();

final class ProfileGroupsCountProvider
    extends $FunctionalProvider<AsyncValue<int>, int, Stream<int>>
    with $FutureModifier<int>, $StreamProvider<int> {
  ProfileGroupsCountProvider._({
    required ProfileGroupsCountFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'profileGroupsCountProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$profileGroupsCountHash();

  @override
  String toString() {
    return r'profileGroupsCountProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $StreamProviderElement<int> $createElement($ProviderPointer pointer) =>
      $StreamProviderElement(pointer);

  @override
  Stream<int> create(Ref ref) {
    final argument = this.argument as int;
    return profileGroupsCount(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is ProfileGroupsCountProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$profileGroupsCountHash() =>
    r'c82d409c32b5467619c51bba28b2066b6ea09c59';

final class ProfileGroupsCountFamily extends $Family
    with $FunctionalFamilyOverride<Stream<int>, int> {
  ProfileGroupsCountFamily._()
    : super(
        retry: null,
        name: r'profileGroupsCountProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProfileGroupsCountProvider call(int profileId) =>
      ProfileGroupsCountProvider._(argument: profileId, from: this);

  @override
  String toString() => r'profileGroupsCountProvider';
}

/// What the standard extension adds to a profile, or a custom profile's rules.

@ProviderFor(ProfileRules)
final profileRulesProvider = ProfileRulesFamily._();

/// What the standard extension adds to a profile, or a custom profile's rules.
final class ProfileRulesProvider
    extends $StreamNotifierProvider<ProfileRules, List<Rule>> {
  /// What the standard extension adds to a profile, or a custom profile's rules.
  ProfileRulesProvider._({
    required ProfileRulesFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'profileRulesProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$profileRulesHash();

  @override
  String toString() {
    return r'profileRulesProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ProfileRules create() => ProfileRules();

  @override
  bool operator ==(Object other) {
    return other is ProfileRulesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$profileRulesHash() => r'f13b77c76b86f66a99953b2854024acf33454f7b';

/// What the standard extension adds to a profile, or a custom profile's rules.

final class ProfileRulesFamily extends $Family
    with
        $ClassFamilyOverride<
          ProfileRules,
          AsyncValue<List<Rule>>,
          List<Rule>,
          Stream<List<Rule>>,
          int
        > {
  ProfileRulesFamily._()
    : super(
        retry: null,
        name: r'profileRulesProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// What the standard extension adds to a profile, or a custom profile's rules.

  ProfileRulesProvider call(int profileId) =>
      ProfileRulesProvider._(argument: profileId, from: this);

  @override
  String toString() => r'profileRulesProvider';
}

/// What the standard extension adds to a profile, or a custom profile's rules.

abstract class _$ProfileRules extends $StreamNotifier<List<Rule>> {
  late final _$args = ref.$arg as int;
  int get profileId => _$args;

  Stream<List<Rule>> build(int profileId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<List<Rule>>, List<Rule>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<Rule>>, List<Rule>>,
              AsyncValue<List<Rule>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(ProxyGroups)
final proxyGroupsProvider = ProxyGroupsFamily._();

final class ProxyGroupsProvider
    extends $StreamNotifierProvider<ProxyGroups, List<ProxyGroup>> {
  ProxyGroupsProvider._({
    required ProxyGroupsFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'proxyGroupsProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$proxyGroupsHash();

  @override
  String toString() {
    return r'proxyGroupsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ProxyGroups create() => ProxyGroups();

  @override
  bool operator ==(Object other) {
    return other is ProxyGroupsProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$proxyGroupsHash() => r'06c102cc212c13fce70b2e19d51250b230e9e54e';

final class ProxyGroupsFamily extends $Family
    with
        $ClassFamilyOverride<
          ProxyGroups,
          AsyncValue<List<ProxyGroup>>,
          List<ProxyGroup>,
          Stream<List<ProxyGroup>>,
          int
        > {
  ProxyGroupsFamily._()
    : super(
        retry: null,
        name: r'proxyGroupsProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProxyGroupsProvider call(int profileId) =>
      ProxyGroupsProvider._(argument: profileId, from: this);

  @override
  String toString() => r'proxyGroupsProvider';
}

abstract class _$ProxyGroups extends $StreamNotifier<List<ProxyGroup>> {
  late final _$args = ref.$arg as int;
  int get profileId => _$args;

  Stream<List<ProxyGroup>> build(int profileId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<ProxyGroup>>, List<ProxyGroup>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<ProxyGroup>>, List<ProxyGroup>>,
              AsyncValue<List<ProxyGroup>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(CustomProxies)
final customProxiesProvider = CustomProxiesProvider._();

final class CustomProxiesProvider
    extends $StreamNotifierProvider<CustomProxies, List<CustomProxy>> {
  CustomProxiesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'customProxiesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$customProxiesHash();

  @$internal
  @override
  CustomProxies create() => CustomProxies();
}

String _$customProxiesHash() => r'0bdcc748c64b67914741a6db78536296cadd9f84';

abstract class _$CustomProxies extends $StreamNotifier<List<CustomProxy>> {
  Stream<List<CustomProxy>> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<CustomProxy>>, List<CustomProxy>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<CustomProxy>>, List<CustomProxy>>,
              AsyncValue<List<CustomProxy>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(ProxyDialers)
final proxyDialersProvider = ProxyDialersFamily._();

final class ProxyDialersProvider
    extends $StreamNotifierProvider<ProxyDialers, Map<int, String>> {
  ProxyDialersProvider._({
    required ProxyDialersFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'proxyDialersProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$proxyDialersHash();

  @override
  String toString() {
    return r'proxyDialersProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ProxyDialers create() => ProxyDialers();

  @override
  bool operator ==(Object other) {
    return other is ProxyDialersProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$proxyDialersHash() => r'ac852d78257e7fd6a4203a9e41904b2f63a9a19f';

final class ProxyDialersFamily extends $Family
    with
        $ClassFamilyOverride<
          ProxyDialers,
          AsyncValue<Map<int, String>>,
          Map<int, String>,
          Stream<Map<int, String>>,
          int
        > {
  ProxyDialersFamily._()
    : super(
        retry: null,
        name: r'proxyDialersProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProxyDialersProvider call(int profileId) =>
      ProxyDialersProvider._(argument: profileId, from: this);

  @override
  String toString() => r'proxyDialersProvider';
}

abstract class _$ProxyDialers extends $StreamNotifier<Map<int, String>> {
  late final _$args = ref.$arg as int;
  int get profileId => _$args;

  Stream<Map<int, String>> build(int profileId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<Map<int, String>>, Map<int, String>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<Map<int, String>>, Map<int, String>>,
              AsyncValue<Map<int, String>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(ProfileDisabledRuleIds)
final profileDisabledRuleIdsProvider = ProfileDisabledRuleIdsFamily._();

final class ProfileDisabledRuleIdsProvider
    extends $StreamNotifierProvider<ProfileDisabledRuleIds, List<int>> {
  ProfileDisabledRuleIdsProvider._({
    required ProfileDisabledRuleIdsFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'profileDisabledRuleIdsProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$profileDisabledRuleIdsHash();

  @override
  String toString() {
    return r'profileDisabledRuleIdsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ProfileDisabledRuleIds create() => ProfileDisabledRuleIds();

  @override
  bool operator ==(Object other) {
    return other is ProfileDisabledRuleIdsProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$profileDisabledRuleIdsHash() =>
    r'2139a32175cef8468d940a4c3075ee61b212b2cf';

final class ProfileDisabledRuleIdsFamily extends $Family
    with
        $ClassFamilyOverride<
          ProfileDisabledRuleIds,
          AsyncValue<List<int>>,
          List<int>,
          Stream<List<int>>,
          int
        > {
  ProfileDisabledRuleIdsFamily._()
    : super(
        retry: null,
        name: r'profileDisabledRuleIdsProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProfileDisabledRuleIdsProvider call(int profileId) =>
      ProfileDisabledRuleIdsProvider._(argument: profileId, from: this);

  @override
  String toString() => r'profileDisabledRuleIdsProvider';
}

abstract class _$ProfileDisabledRuleIds extends $StreamNotifier<List<int>> {
  late final _$args = ref.$arg as int;
  int get profileId => _$args;

  Stream<List<int>> build(int profileId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<List<int>>, List<int>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<int>>, List<int>>,
              AsyncValue<List<int>>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
