part of 'database.dart';

@DataClassName('RawProfile')
class Profiles extends Table {
  @override
  String get tableName => 'profiles';

  IntColumn get id => integer()();

  TextColumn get type => textEnum<ProfileType>()();

  TextColumn get label => text()();

  TextColumn get currentGroupName => text().nullable()();

  TextColumn get url => text()();

  TextColumn get ageSecretKey => text().nullable()();

  DateTimeColumn get lastUpdateDate => dateTime().nullable()();

  /// Older builds pick a script or added rules by it; this build runs both.
  TextColumn get extendType => text()();

  IntColumn get scriptId => integer().nullable()();

  /// Read only by the v25 upgrade, which moves it into [exitTargets].
  TextColumn get matchTarget => text().nullable()();

  TextColumn get exitTargets =>
      text().map(const StringMapConverter()).nullable()();

  IntColumn get autoUpdateDurationMillis => integer()();

  TextColumn get subscriptionInfo =>
      text().map(const SubscriptionInfoConverter()).nullable()();

  BoolColumn get autoUpdate => boolean()();

  TextColumn get selectedMap => text().map(const StringMapConverter())();

  TextColumn get unfoldSet => text().map(const StringSetConverter())();

  IntColumn get order => integer().nullable()();

  TextColumn get overrides =>
      text().map(const ProfileOverridesConverter()).nullable()();

  @override
  Set<Column> get primaryKey => {id};
}

class ProfileOverridesConverter
    extends TypeConverter<ProfileOverrides?, String?> {
  const ProfileOverridesConverter();

  @override
  ProfileOverrides? fromSql(String? fromDb) {
    if (fromDb == null) return null;
    return decodeOrRestoreDefault(
      'profile overrides',
      () => ProfileOverrides.safeFromJson(json.decode(fromDb)),
      () => null,
    );
  }

  @override
  String? toSql(ProfileOverrides? value) {
    if (value == null || value == const ProfileOverrides()) return null;
    return json.encode(value.toJson());
  }
}

class SubscriptionInfoConverter
    extends TypeConverter<SubscriptionInfo?, String?> {
  const SubscriptionInfoConverter();

  @override
  SubscriptionInfo? fromSql(String? fromDb) {
    if (fromDb == null) return null;
    return decodeOrRestoreDefault(
      'subscription info',
      () => SubscriptionInfo.fromJson(json.decode(fromDb)),
      () => null,
    );
  }

  @override
  String? toSql(SubscriptionInfo? value) {
    if (value == null) return null;
    return json.encode(value.toJson());
  }
}

@DriftAccessor(tables: [Profiles])
class ProfilesDao extends DatabaseAccessor<Database> with _$ProfilesDaoMixin {
  ProfilesDao(super.attachedDatabase);

  Selectable<Profile> query() {
    return profiles.readable(
      (row) => row.toProfile(),
      orderBy: [
        (t) => OrderingTerm(expression: t.order, nulls: NullsOrder.last),
        (t) => OrderingTerm.asc(t.id),
      ],
    );
  }

  /// The order [query] reads profiles back in.
  static int compare(Profile a, Profile b) => switch ((a.order, b.order)) {
    (final x?, final y?) when x != y => x.compareTo(y),
    (null, _?) => 1,
    (_?, null) => -1,
    _ => a.id.compareTo(b.id),
  };

  Future<void> setAll(Iterable<Profile> profiles) async {
    await batch((b) async {
      setAllWithBatch(b, profiles);
    });
  }

  Future<void> putAll<T extends Table, D extends DataClass>(
    Iterable<Insertable<D>> items,
  ) async {
    await batch((b) async {
      putAllWithBatch(b, items);
    });
  }

  void putAllWithBatch<T extends Table, D extends DataClass>(
    Batch batch,
    Iterable<Insertable<D>> items,
  ) {
    batch.insertAllOnConflictUpdate(profiles, items);
  }

  Selectable<int> ids() {
    final query = profiles.selectOnly()..addColumns([profiles.id]);
    return query.map((row) => row.read(profiles.id)!);
  }

  Selectable<int> customIds() {
    final query = profiles.selectOnly()
      ..addColumns([profiles.id])
      ..where(profiles.type.equalsValue(ProfileType.custom));
    return query.map((row) => row.read(profiles.id)!);
  }

  Future<Profile?> get(int id) => profiles
      .readable((row) => row.toProfile(), where: (t) => t.id.equals(id))
      .getSingleOrNull();

  Selectable<String> fileNames() => ids().map((id) => '$id.yaml');

  void setAllWithBatch(Batch batch, Iterable<Profile> profiles) {
    final List<ProfilesCompanion> items = [];
    final List<int> ids = [];
    profiles.forEachIndexed((index, profile) {
      ids.add(profile.id);
      items.add(profile.toCompanion(index));
    });

    this.profiles.setAll(batch, items, deleteFilter: (t) => t.id.isNotIn(ids));
  }
}

extension RawProfilExt on RawProfile {
  Profile toProfile() {
    return Profile(
      id: id,
      type: type,
      label: label,
      currentGroupName: currentGroupName,
      url: url,
      ageSecretKey: ageSecretKey ?? '',
      lastUpdateDate: lastUpdateDate,
      autoUpdateDuration: Duration(milliseconds: autoUpdateDurationMillis),
      subscriptionInfo: subscriptionInfo,
      autoUpdate: autoUpdate,
      selectedMap: selectedMap,
      unfoldSet: unfoldSet,
      scriptId: scriptId,
      exitTargets: exitTargets ?? const {},
      order: order,
      overrides: overrides ?? const ProfileOverrides(),
    );
  }
}

extension ProfilesCompanionExt on Profile {
  ProfilesCompanion toCompanion([int? order]) {
    return ProfilesCompanion.insert(
      id: Value(id),
      type: type,
      label: label,
      currentGroupName: Value(currentGroupName),
      url: url,
      ageSecretKey: Value(ageSecretKey.isEmpty ? null : ageSecretKey),
      lastUpdateDate: Value(lastUpdateDate),
      autoUpdateDurationMillis: autoUpdateDuration.inMilliseconds,
      subscriptionInfo: Value(subscriptionInfo),
      autoUpdate: autoUpdate,
      selectedMap: selectedMap,
      unfoldSet: unfoldSet,
      extendType: scriptId == null ? 'standard' : 'script',
      scriptId: Value(scriptId),
      exitTargets: Value(exitTargets),
      order: Value(order ?? this.order),
      overrides: Value(overrides),
    );
  }
}
