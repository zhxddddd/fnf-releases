<div align=center>

[![Release Downloads](https://img.shields.io/github/downloads/chen08209/FlClash/TAG/total?style=flat-square&logo=github)](https://img.shields.io/github/downloads/chen08209/FlClash/TAG/)

</div>

**Download based on your OS:**

<div align=left>
<table>
    <thead align=left>
        <tr>
            <th>OS</th>
            <th>Download</th>
        </tr>
    </thead>
    <tbody align=left>
        <tr>
        <td>Android</td>
            <td>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-android-arm64.apk"><img src="https://img.shields.io/badge/APK-ARMv8-168039.svg?logo=android"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-android-armv7.apk"><img src="https://img.shields.io/badge/APK-ARMv7-45bf55.svg?logo=android"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-android-amd64.apk"><img src="https://img.shields.io/badge/APK-x64-96ed89.svg?logo=android"></a>
            </td>
        </tr>
        <tr>
            <td>Windows</td>
            <td>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-windows-amd64-setup.exe"><img src="https://img.shields.io/badge/Setup-x64-2d7d9a.svg?logo=windows"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-windows-amd64-portable.zip"><img src="https://img.shields.io/badge/Portable-x64-67b7d1.svg?logo=windows"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-windows-arm64-setup.exe"><img src="https://img.shields.io/badge/Setup-ARM64-2d7d9a.svg?logo=windows"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-windows-arm64-portable.zip"><img src="https://img.shields.io/badge/Portable-ARM64-67b7d1.svg?logo=windows"></a>
            </td>
        </tr>
        <tr>
            <td>macOS</td>
            <td>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-macos-arm64.dmg"><img src="https://img.shields.io/badge/DMG-Apple%20Silicon-%23000000.svg?logo=apple"></a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-macos-amd64.dmg"><img src="https://img.shields.io/badge/DMG-Intel%20X64-%2300A9E0.svg?logo=apple"></a><br>
            </td>
        </tr>
        <tr>
            <td>Linux</td>
            <td>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-amd64.AppImage"><img src="https://img.shields.io/badge/AppImage-x64-f84e29.svg?logo=linux"> </a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-amd64.deb"><img src="https://img.shields.io/badge/DebPackage-x64-FF9966.svg?logo=debian"> </a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-amd64.rpm"><img src="https://img.shields.io/badge/RpmPackage-x64-F1B42F.svg?logo=redhat"> </a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-arm64.AppImage"><img src="https://img.shields.io/badge/AppImage-ARM64-f84e29.svg?logo=linux"> </a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-arm64.deb"><img src="https://img.shields.io/badge/DebPackage-ARM64-FF9966.svg?logo=debian"> </a><br>
                <a href="https://github.com/chen08209/FlClash/releases/download/TAG/FlClash-VERSION-linux-arm64.rpm"><img src="https://img.shields.io/badge/RpmPackage-ARM64-F1B42F.svg?logo=redhat"> </a>
            </td>
        </tr>
    </tbody>
</table>


</div>

<div dir="ltr">

**List of all changes:** [ChangeLog](https://github.com/chen08209/FlClash/blob/main/CHANGELOG.md)

</div>