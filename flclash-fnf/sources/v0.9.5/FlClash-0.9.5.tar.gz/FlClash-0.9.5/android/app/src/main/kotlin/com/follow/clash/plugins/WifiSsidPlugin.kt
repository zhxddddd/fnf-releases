package com.follow.clash.plugins

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import com.follow.clash.common.Components
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.RequestPermissionsResultListener
import java.util.concurrent.ConcurrentHashMap

class WifiSsidPlugin : FlutterPlugin, MethodCallHandler, ActivityAware {
    private lateinit var channel: MethodChannel
    private var context: Context? = null
    private var activity: Activity? = null
    private var wifiManager: WifiManager? = null
    private var connectivityManager: ConnectivityManager? = null
    private var activityBinding: ActivityPluginBinding? = null
    private var pendingPermissionResult: Result? = null
    private var rationaleBeforeRequest: Map<String, Boolean> = emptyMap()
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null
    private val wifiInfoByNetwork = ConcurrentHashMap<Network, WifiInfo>()
    private val pendingSsidResults = mutableListOf<Result>()
    @Volatile
    private var hasPendingSsid = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var ssidTimeout: Runnable? = null

    private val permissionResultListener = RequestPermissionsResultListener { requestCode, _, _ ->
        if (requestCode != REQUEST_CODE_LOCATION && requestCode != REQUEST_CODE_BACKGROUND_LOCATION) {
            return@RequestPermissionsResultListener false
        }
        val result = pendingPermissionResult
            ?: return@RequestPermissionsResultListener false
        val currentActivity = activity
        if (currentActivity == null) {
            pendingPermissionResult = null
            result.error(ERROR_UNAVAILABLE, "Activity not available", null)
            return@RequestPermissionsResultListener true
        }
        // R+ dialogs never offer "Allow all the time"; asking for it alone opens Settings.
        if (
            requestCode == REQUEST_CODE_LOCATION &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            hasForegroundLocation(currentActivity) &&
            !hasBackgroundLocation(currentActivity)
        ) {
            requestBackgroundLocation(currentActivity)
            return@RequestPermissionsResultListener true
        }
        pendingPermissionResult = null
        result.success(settleRequest(currentActivity))
        true
    }

    companion object {
        private const val CHANNEL_NAME = "${Components.PACKAGE_NAME}/wifi_ssid"
        private const val METHOD_GET_SSID = "getSsid"
        private const val METHOD_CHECK_PERMISSION = "checkPermission"
        private const val METHOD_REQUEST_PERMISSION = "requestPermission"
        private const val ERROR_UNAVAILABLE = "UNAVAILABLE"
        private const val ERROR_IN_PROGRESS = "IN_PROGRESS"
        // Every plugin on the activity sees every result; stay clear of the app's codes.
        private const val REQUEST_CODE_LOCATION = 2101
        private const val REQUEST_CODE_BACKGROUND_LOCATION = 2102
        private const val DENIED_PERMISSIONS_PREFERENCES = "wifi_ssid_denied_permissions"
        private const val SSID_TIMEOUT_MILLIS = 3_000L

        // Values must match the WifiSsidPermission index in rust_api
        private const val PERMISSION_GRANTED = 0
        private const val PERMISSION_DENIED = 1
        private const val PERMISSION_PERMANENTLY_DENIED = 2
    }

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, CHANNEL_NAME)
        channel.setMethodCallHandler(this)
        wifiManager = binding.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        connectivityManager = binding.applicationContext.getSystemService(
            Context.CONNECTIVITY_SERVICE,
        ) as? ConnectivityManager
        if (hasForegroundLocation(binding.applicationContext)) {
            registerWifiNetworkCallback()
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        completePendingSsidResults(
            errorMessage = "Plugin detached before SSID lookup completed",
        )
        channel.setMethodCallHandler(null)
        unregisterWifiNetworkCallback()
        detachFromActivity(cancelPermissionRequest = true)
        context = null
        wifiManager = null
        connectivityManager = null
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activityBinding?.removeRequestPermissionsResultListener(permissionResultListener)
        activityBinding = binding
        activity = binding.activity
        binding.addRequestPermissionsResultListener(permissionResultListener)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        detachFromActivity(cancelPermissionRequest = false)
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivity() {
        detachFromActivity(cancelPermissionRequest = true)
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        when (call.method) {
            METHOD_GET_SSID -> getSsid(result)
            METHOD_CHECK_PERMISSION -> checkPermission(result)
            METHOD_REQUEST_PERMISSION -> requestPermission(result)
            else -> result.notImplemented()
        }
    }

    private fun checkPermission(result: Result) {
        val ctx = context ?: run {
            result.error(ERROR_UNAVAILABLE, "Context not available", null)
            return
        }
        refreshWifiNetworkCallback()
        forgetGrantedDenials(ctx)
        result.success(
            if (missingPermission(ctx) == null) PERMISSION_GRANTED else PERMISSION_DENIED,
        )
    }

    private fun requestPermission(result: Result) {
        val act = activity ?: run {
            result.error(ERROR_UNAVAILABLE, "Activity not available", null)
            return
        }
        val ctx = context ?: run {
            result.error(ERROR_UNAVAILABLE, "Context not available", null)
            return
        }
        if (missingPermission(ctx) == null) {
            refreshWifiNetworkCallback()
            forgetGrantedDenials(ctx)
            result.success(PERMISSION_GRANTED)
            return
        }
        if (pendingPermissionResult != null) {
            result.error(ERROR_IN_PROGRESS, "A permission request is already active", null)
            return
        }
        pendingPermissionResult = result
        if (hasForegroundLocation(ctx)) {
            requestBackgroundLocation(act)
        } else {
            requestForegroundLocation(act)
        }
    }

    private fun requestForegroundLocation(activity: Activity) {
        // Q accepts the background permission in the same dialog; R+ rejects the
        // combined request and needs it asked separately once foreground is granted.
        val permissions = if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
        }
        launchPermissionRequest(activity, permissions, REQUEST_CODE_LOCATION)
    }

    private fun requestBackgroundLocation(activity: Activity) {
        launchPermissionRequest(
            activity,
            arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
            REQUEST_CODE_BACKGROUND_LOCATION,
        )
    }

    private fun launchPermissionRequest(
        activity: Activity,
        permissions: Array<String>,
        requestCode: Int,
    ) {
        rationaleBeforeRequest = permissions.associateWith {
            ActivityCompat.shouldShowRequestPermissionRationale(activity, it)
        }
        ActivityCompat.requestPermissions(activity, permissions, requestCode)
    }

    private fun settleRequest(activity: Activity): Int {
        val rationaleBefore = rationaleBeforeRequest
        rationaleBeforeRequest = emptyMap()
        refreshWifiNetworkCallback()
        forgetGrantedDenials(activity)
        val missing = missingPermission(activity) ?: return PERMISSION_GRANTED
        return resolveDenial(activity, missing, rationaleBefore[missing] == true)
    }

    // Rationale is false both before the first prompt and after a permanent denial;
    // how it moved across the request and a persisted earlier denial tell them apart.
    private fun resolveDenial(
        activity: Activity,
        permission: String,
        rationaleBefore: Boolean,
    ): Int {
        val preferences = deniedPermissions(activity)
        val deniedBefore = preferences.getBoolean(permission, false)
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            preferences.edit { putBoolean(permission, true) }
            return PERMISSION_DENIED
        }
        if (rationaleBefore) {
            preferences.edit { putBoolean(permission, true) }
            return PERMISSION_PERMANENTLY_DENIED
        }
        return if (deniedBefore) PERMISSION_PERMANENTLY_DENIED else PERMISSION_DENIED
    }

    private fun forgetGrantedDenials(context: Context) {
        val preferences = deniedPermissions(context)
        val granted = preferences.all.keys.filter { isGranted(context, it) }
        if (granted.isNotEmpty()) {
            preferences.edit { granted.forEach(::remove) }
        }
    }

    private fun deniedPermissions(context: Context) =
        context.getSharedPreferences(DENIED_PERMISSIONS_PREFERENCES, Context.MODE_PRIVATE)

    private fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun hasForegroundLocation(context: Context): Boolean =
        isGranted(context, Manifest.permission.ACCESS_FINE_LOCATION)

    // Since Q the SSID reads as UNKNOWN_SSID from the background without this
    // permission, which is where the on-demand check spends most of its time.
    private fun hasBackgroundLocation(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            isGranted(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION)

    private fun missingPermission(context: Context): String? = when {
        !hasForegroundLocation(context) -> Manifest.permission.ACCESS_FINE_LOCATION
        !hasBackgroundLocation(context) -> Manifest.permission.ACCESS_BACKGROUND_LOCATION
        else -> null
    }

    private fun getSsid(result: Result) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val ctx = context ?: run {
                result.error(ERROR_UNAVAILABLE, "Context not available", null)
                return
            }
            if (!hasForegroundLocation(ctx)) {
                result.success(null)
                return
            }
            if (connectivityManager == null) {
                result.error(ERROR_UNAVAILABLE, "ConnectivityManager not available", null)
                return
            }
            val ssid = currentSsid()
            if (ssid != null) {
                result.success(ssid)
                return
            }
            pendingSsidResults.add(result)
            hasPendingSsid = true
            if (!registerWifiNetworkCallback()) {
                completePendingSsidResults(ssid = null)
                return
            }
            scheduleSsidTimeout()
            return
        }

        val wm = wifiManager ?: run {
            result.error(ERROR_UNAVAILABLE, "WifiManager not available", null)
            return
        }
        @Suppress("DEPRECATION")
        result.success(normalizeSsid(wm.connectionInfo?.ssid))
    }

    private fun currentSsid(): String? {
        val activeNetwork = connectivityManager?.activeNetwork
        val info = activeNetwork?.let(wifiInfoByNetwork::get)
            ?: wifiInfoByNetwork.values.firstOrNull()
        return normalizeSsid(info?.ssid)
    }

    private fun normalizeSsid(ssid: String?): String? {
        val normalized = ssid?.removeSurrounding("\"")
        return normalized?.takeIf {
            it.isNotEmpty() && it != WifiManager.UNKNOWN_SSID && it != "0x"
        }
    }

    private fun refreshWifiNetworkCallback() {
        unregisterWifiNetworkCallback()
        registerWifiNetworkCallback()
    }

    private fun registerWifiNetworkCallback(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return false
        }
        val ctx = context ?: return false
        if (!hasForegroundLocation(ctx)) {
            unregisterWifiNetworkCallback()
            return false
        }
        if (wifiNetworkCallback != null) {
            return true
        }
        val cm = connectivityManager ?: return false
        val callback = object : ConnectivityManager.NetworkCallback(FLAG_INCLUDE_LOCATION_INFO) {
            override fun onCapabilitiesChanged(
                network: Network,
                capabilities: NetworkCapabilities,
            ) {
                val wifiInfo = capabilities.transportInfo as? WifiInfo
                if (wifiInfo == null) {
                    wifiInfoByNetwork.remove(network)
                } else {
                    wifiInfoByNetwork[network] = wifiInfo
                }
                if (!hasPendingSsid) {
                    return
                }
                currentSsid()?.let { ssid ->
                    mainHandler.post {
                        completePendingSsidResults(ssid = ssid)
                    }
                }
            }

            override fun onLost(network: Network) {
                wifiInfoByNetwork.remove(network)
            }
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        return runCatching { cm.registerNetworkCallback(request, callback) }
            .onSuccess { wifiNetworkCallback = callback }
            .isSuccess
    }

    private fun scheduleSsidTimeout() {
        if (ssidTimeout != null) {
            return
        }
        val timeout = Runnable {
            ssidTimeout = null
            completePendingSsidResults(ssid = currentSsid())
        }
        ssidTimeout = timeout
        mainHandler.postDelayed(timeout, SSID_TIMEOUT_MILLIS)
    }

    private fun completePendingSsidResults(
        ssid: String? = null,
        errorMessage: String? = null,
    ) {
        val timeout = ssidTimeout
        ssidTimeout = null
        if (timeout != null) {
            mainHandler.removeCallbacks(timeout)
        }
        val results = pendingSsidResults.toList()
        pendingSsidResults.clear()
        hasPendingSsid = false
        results.forEach { result ->
            if (errorMessage == null) {
                result.success(ssid)
            } else {
                result.error(ERROR_UNAVAILABLE, errorMessage, null)
            }
        }
    }

    private fun unregisterWifiNetworkCallback() {
        val callback = wifiNetworkCallback
        wifiNetworkCallback = null
        if (callback != null) {
            connectivityManager?.let { manager ->
                runCatching { manager.unregisterNetworkCallback(callback) }
            }
        }
        wifiInfoByNetwork.clear()
    }

    private fun detachFromActivity(cancelPermissionRequest: Boolean) {
        activityBinding?.removeRequestPermissionsResultListener(permissionResultListener)
        activityBinding = null
        activity = null
        if (cancelPermissionRequest) {
            rationaleBeforeRequest = emptyMap()
            completePendingPermissionRequest(
                "Activity detached before permission request completed",
            )
        }
    }

    private fun completePendingPermissionRequest(message: String) {
        pendingPermissionResult?.error(ERROR_UNAVAILABLE, message, null)
        pendingPermissionResult = null
    }
}
