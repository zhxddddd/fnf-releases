import {
  appConfigPath,
  controledMihomoConfigPath,
  dataDir,
  logDir,
  mihomoTestDir,
  mihomoWorkDir,
  overrideConfigPath,
  overrideDir,
  profileConfigPath,
  profilePath,
  profilesDir,
  resourcesFilesDir,
  subStoreBackendPath,
  subStoreDir,
  subStoreFrontendDir,
  themesDir
} from './dirs'
import {
  defaultConfig,
  defaultControledMihomoConfig,
  defaultOverrideConfig,
  defaultProfile,
  defaultProfileConfig
} from './template'
import { stringifyYaml } from './yaml'
import { mkdir, writeFile, cp, rm, readdir } from 'fs/promises'
import { existsSync } from 'fs'
import path from 'path'
import {
  startPacServer,
  startSubStoreBackendServer,
  startSubStoreFrontendServer
} from '../resolve/server'
import { triggerSysProxy } from '../sys/sysproxy'
import {
  getAppConfig,
  getControledMihomoConfig,
  patchAppConfig,
  patchControledMihomoConfig
} from '../config'
import { app } from 'electron'
import { startSSIDCheck } from '../sys/ssid'
import { startNetworkDetection } from '../core/manager'
import { initKeyManager } from '../service/manager'
import { appendAppLog } from './log'

async function initDirs(): Promise<void> {
  if (!existsSync(dataDir())) {
    await mkdir(dataDir())
  }
  const dirs = [
    themesDir(),
    profilesDir(),
    overrideDir(),
    mihomoWorkDir(),
    logDir(),
    mihomoTestDir(),
    subStoreDir()
  ]
  await Promise.all(
    dirs.map(async (dir) => {
      if (!existsSync(dir)) {
        await mkdir(dir, { recursive: true })
      }
    })
  )
}

async function initConfig(): Promise<void> {
  const configTasks: Promise<void>[] = []

  if (!existsSync(appConfigPath())) {
    configTasks.push(writeFile(appConfigPath(), stringifyYaml(defaultConfig)))
  }
  if (!existsSync(profileConfigPath())) {
    configTasks.push(writeFile(profileConfigPath(), stringifyYaml(defaultProfileConfig)))
  }
  if (!existsSync(overrideConfigPath())) {
    configTasks.push(writeFile(overrideConfigPath(), stringifyYaml(defaultOverrideConfig)))
  }
  if (!existsSync(profilePath('default'))) {
    configTasks.push(writeFile(profilePath('default'), stringifyYaml(defaultProfile)))
  }
  if (!existsSync(controledMihomoConfigPath())) {
    configTasks.push(
      writeFile(controledMihomoConfigPath(), stringifyYaml(defaultControledMihomoConfig))
    )
  }

  if (configTasks.length > 0) {
    await Promise.all(configTasks)
  }
}

async function initFiles(): Promise<void> {
  const copy = async (file: string, customTargetPath?: string): Promise<void> => {
    if (customTargetPath) {
      const sourcePath = path.join(resourcesFilesDir(), file)
      if (!existsSync(customTargetPath) && existsSync(sourcePath)) {
        await cp(sourcePath, customTargetPath, { recursive: true })
      }
      return
    }

    const targetPath = path.join(mihomoWorkDir(), file)
    const testTargetPath = path.join(mihomoTestDir(), file)
    const sourcePath = path.join(resourcesFilesDir(), file)
    if (!existsSync(targetPath) && existsSync(sourcePath)) {
      await cp(sourcePath, targetPath, { recursive: true })
    }
    if (!existsSync(testTargetPath) && existsSync(sourcePath)) {
      await cp(sourcePath, testTargetPath, { recursive: true })
    }
  }
  await Promise.all([
    copy('country.mmdb'),
    copy('geoip.metadb'),
    copy('geoip.dat'),
    copy('geosite.dat'),
    copy('ASN.mmdb'),
    copy('BundleMRS.7z'),
    copy('sub-store.bundle.js', subStoreBackendPath()),
    copy('sub-store-frontend', subStoreFrontendDir())
  ])
}

async function cleanup(): Promise<void> {
  const [files, logs, { maxLogDays = 7 }] = await Promise.all([
    readdir(dataDir()),
    readdir(logDir()),
    getAppConfig()
  ])
  const expiredBefore = Date.now() - maxLogDays * 24 * 60 * 60 * 1000
  const updateCacheFiles = files.filter(
    (file) => file.endsWith('.exe') || file.endsWith('.pkg') || file.endsWith('.7z')
  )
  const expiredLogs = logs.filter((log) => {
    const dateStr = log.match(/(\d{4}-\d{1,2}-\d{1,2})(?=\.log$)/)?.[1]
    if (!dateStr) return false

    const timestamp = new Date(dateStr).getTime()
    return !Number.isNaN(timestamp) && timestamp < expiredBefore
  })

  await Promise.all([
    ...updateCacheFiles.map((file) => rm(path.join(dataDir(), file)).catch(() => {})),
    ...expiredLogs.map((log) => rm(path.join(logDir(), log)).catch(() => {}))
  ])
}

async function migration(): Promise<void> {
  const [appConfig, mihomoConfig] = await Promise.all([getAppConfig(), getControledMihomoConfig()])

  const mihomoConfigPatch: Partial<MihomoConfig> = {}

  for (const key in defaultControledMihomoConfig) {
    if (
      !(key in mihomoConfig) &&
      defaultControledMihomoConfig[key as keyof MihomoConfig] !== undefined
    ) {
      ;(mihomoConfigPatch as Record<string, unknown>)[key] =
        defaultControledMihomoConfig[key as keyof MihomoConfig]
    }
  }

  if (mihomoConfig['external-controller-pipe' as keyof MihomoConfig]) {
    mihomoConfigPatch['external-controller-pipe' as keyof MihomoConfig] = undefined as never
  }
  if (mihomoConfig['external-controller-unix' as keyof MihomoConfig]) {
    mihomoConfigPatch['external-controller-unix' as keyof MihomoConfig] = undefined as never
  }

  if (mihomoConfig['external-controller'] === undefined) {
    mihomoConfigPatch['external-controller'] = ''
  }
  if (mihomoConfig['global-client-fingerprint'] !== undefined) {
    mihomoConfigPatch['global-client-fingerprint'] = undefined as never
  }

  if (Object.keys(mihomoConfigPatch).length > 0) {
    await patchControledMihomoConfig(mihomoConfigPatch)
  }

  const appConfigPatch: Partial<AppConfig> = {}

  for (const key in defaultConfig) {
    if (!(key in appConfig) && defaultConfig[key as keyof AppConfig] !== undefined) {
      ;(appConfigPatch as Record<string, unknown>)[key] = defaultConfig[key as keyof AppConfig]
    }
  }

  if (Object.keys(appConfigPatch).length > 0) {
    await patchAppConfig(appConfigPatch)
  }
}

function initDeeplink(): void {
  if (process.defaultApp) {
    if (process.argv.length >= 2) {
      app.setAsDefaultProtocolClient('clash', process.execPath, [path.resolve(process.argv[1])])
      app.setAsDefaultProtocolClient('mihomo', process.execPath, [path.resolve(process.argv[1])])
      app.setAsDefaultProtocolClient('sparkle', process.execPath, [path.resolve(process.argv[1])])
    }
  } else {
    app.setAsDefaultProtocolClient('clash')
    app.setAsDefaultProtocolClient('mihomo')
    app.setAsDefaultProtocolClient('sparkle')
  }
}

function runBackgroundInitTask(name: string, task: Promise<void>): void {
  task.catch((error) => {
    appendAppLog(`[App]: background init task ${name} failed, ${error}\n`).catch(() => {})
  })
}

function startBackgroundInit(appConfig: AppConfig): void {
  const { sysProxy, onlyActiveDevice = false, networkDetection = false } = appConfig

  runBackgroundInitTask('substore frontend', startSubStoreFrontendServer())
  runBackgroundInitTask('substore backend', startSubStoreBackendServer())
  runBackgroundInitTask('ssid check', startSSIDCheck())

  if (networkDetection) {
    runBackgroundInitTask('network detection', startNetworkDetection())
  }

  runBackgroundInitTask(
    'sysproxy restore',
    (async (): Promise<void> => {
      if (sysProxy.enable) {
        await startPacServer()
      }
      await triggerSysProxy(sysProxy.enable, onlyActiveDevice)
    })()
  )
}

export async function init(): Promise<AppConfig> {
  await initDirs()
  await Promise.all([initConfig(), initFiles()])
  await migration()

  const [appConfig] = await Promise.all([
    getAppConfig(),
    initKeyManager(),
    cleanup().catch(() => {
      // ignore
    })
  ])

  initDeeplink()
  startBackgroundInit(appConfig)
  return appConfig
}
