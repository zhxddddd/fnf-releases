import os from 'os'
import { systemCoreDefaultPath, systemCoreOnlyBuild } from '../../shared/build-flags'

export const defaultConfig: AppConfig = {
  core: systemCoreOnlyBuild ? 'system' : 'mihomo',
  ...(systemCoreOnlyBuild ? { systemCorePath: systemCoreDefaultPath } : {}),
  ...(systemCoreOnlyBuild ? { corePermissionMode: 'elevated' as const } : {}),
  updateChannel: 'stable',
  notificationMode: 'system',
  showUpdateButtonAfterNotification: true,
  silentStart: false,
  appTheme: 'system',
  useWindowFrame: false,
  enableWindowDrag: false,
  proxyInTray: true,
  customTrayIcon: '',
  trayProxyDelayLayout: 'new-line',
  useCustomTrayMenu: false,
  saveLogs: true,
  maxLogDays: 7,
  maxLogFileSizeMB: 20,
  maxLogEntries: 500,
  proxyCols: 'auto',
  connectionDirection: 'asc',
  connectionOrderBy: 'time',
  connectionGroupByProcess: false,
  connectionGroupSort: 'name',
  connectionGroupDirection: 'asc',
  connectionInterval: 500,
  gistSyncEnabled: false,
  gistEncrypted: false,
  useSubStore: true,
  proxyDisplayOrder: 'default',
  autoCheckUpdate: false,
  autoCloseConnection: true,
  closeMode: 'all',
  controlDns: true,
  controlSniff: true,
  hosts: [],
  siderOrder: [
    'sysproxy',
    'tun',
    'dns',
    'sniff',
    'proxy',
    'connection',
    'profile',
    'mihomo',
    'rule',
    'resource',
    'override',
    'log',
    'substore'
  ],
  siderWidth: 250,
  sysProxy: { enable: false, mode: 'manual', guard: false, guardNotify: false },
  disableLoopbackDetector: false,
  disableEmbedCA: false,
  disableSystemCA: false,
  disableNftables: false,
  safePaths: [],
  disableGPU: process.platform === 'win32' && parseInt(os.release().split('.')[2], 10) <= 20000,
  proxyDisplayLayout: 'double',
  groupDisplayLayout: 'double',
  showGroupSelectedProxy: false,
  autoLightweightMode: 'core',
  coreStartupMode: 'post-up',
  serviceRunMode: 'auto',
  serviceCpuAffinity: [],
  delayTestConcurrency: 50,
  delayTestUseGroupApi: false,
  delayTestUrlScope: 'group',
  showProxyDetailTooltip: false
}

export const defaultControledMihomoConfig: Partial<MihomoConfig> = {
  'external-controller': '',
  'external-ui': '',
  'external-ui-url': 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
  'external-controller-cors': {
    'allow-origins': ['https://metacubex.github.io', 'https://board.zash.run.place'],
    'allow-private-network': false
  },
  secret: '',
  ipv6: true,
  mode: 'rule',
  'mixed-port': 7890,
  'socks-port': 0,
  port: 0,
  'redir-port': 0,
  'tproxy-port': 0,
  'allow-lan': false,
  'unified-delay': false,
  'tcp-concurrent': false,
  'log-level': 'info',
  'find-process-mode': 'always',
  'interface-name': '',
  'bind-address': '*',
  'keep-alive-idle': 0,
  'keep-alive-interval': 0,
  'disable-keep-alive': false,
  'lan-allowed-ips': ['0.0.0.0/0', '::/0'],
  'lan-disallowed-ips': [],
  authentication: [],
  'skip-auth-prefixes': ['127.0.0.1/32'],
  tun: {
    enable: false,
    device: process.platform === 'darwin' ? undefined : 'mihomo',
    stack: 'mixed',
    'auto-route': true,
    'auto-redirect': false,
    'auto-detect-interface': true,
    'dns-hijack': ['any:53'],
    'route-exclude-address': [],
    mtu: 1500
  },
  dns: {
    enable: true,
    ipv6: true,
    'respect-rules': false,
    'enhanced-mode': 'fake-ip',
    'fake-ip-range': '198.18.0.1/16',
    'fake-ip-filter': ['*', '+.lan', '+.local', 'time.*.com', 'ntp.*.com', '+.market.xiaomi.com'],
    'use-hosts': false,
    'use-system-hosts': false,
    'default-nameserver': ['tls://223.5.5.5'],
    nameserver: ['https://doh.pub/dns-query', 'https://dns.alidns.com/dns-query'],
    'nameserver-policy': {},
    'proxy-server-nameserver': [],
    'proxy-server-nameserver-policy': {},
    'direct-nameserver': []
  },
  sniffer: {
    enable: true,
    'parse-pure-ip': true,
    'force-dns-mapping': true,
    'override-destination': false,
    sniff: {
      HTTP: {
        ports: [80, 443],
        'override-destination': false
      },
      TLS: {
        ports: [443]
      }
    },
    'skip-domain': ['+.push.apple.com'],
    'skip-dst-address': [
      '91.105.192.0/23',
      '91.108.4.0/22',
      '91.108.8.0/21',
      '91.108.16.0/21',
      '91.108.56.0/22',
      '95.161.64.0/20',
      '149.154.160.0/20',
      '185.76.151.0/24',
      '2001:67c:4e8::/48',
      '2001:b28:f23c::/47',
      '2001:b28:f23f::/48',
      '2a0a:f280:203::/48'
    ]
  },
  profile: {
    'store-selected': true,
    'store-fake-ip': true
  },
  'geo-auto-update': false,
  'geo-update-interval': 24,
  'geodata-mode': false,
  'geox-url': {
    geoip: 'https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat',
    geosite: 'https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat',
    mmdb: 'https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.metadb',
    asn: 'https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/GeoLite2-ASN.mmdb'
  }
}

export const defaultProfileConfig: ProfileConfig = {
  items: []
}

export const defaultOverrideConfig: OverrideConfig = {
  items: []
}

export const defaultProfile: Partial<MihomoConfig> = {
  proxies: [],
  'proxy-groups': [],
  rules: []
}
