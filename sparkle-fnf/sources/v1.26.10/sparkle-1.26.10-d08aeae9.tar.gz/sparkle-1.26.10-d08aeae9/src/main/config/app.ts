import { readFile, writeFile, rename, copyFile, unlink } from 'fs/promises'
import { appConfigPath } from '../utils/dirs'
import { parseYaml, stringifyYaml } from '../utils/yaml'
import { deepMerge } from '../utils/merge'
import { defaultConfig } from '../utils/template'
import { readFileSync, existsSync } from 'fs'
import { systemCoreDefaultPath, systemCoreOnlyBuild } from '../../shared/build-flags'
import { notifyConfigOperation } from '../resolve/webhook'

let appConfig: AppConfig
let writePromise: Promise<void> = Promise.resolve()

function applyBuildConfig(config: AppConfig): AppConfig {
  if (!systemCoreOnlyBuild) return config

  return {
    ...config,
    core: 'system',
    systemCorePath: config.systemCorePath || systemCoreDefaultPath
  }
}

function isValidConfig(config: unknown): config is AppConfig {
  if (!config || typeof config !== 'object') return false
  const cfg = config as Partial<AppConfig>
  return 'sysProxy' in cfg && typeof cfg.sysProxy === 'object' && cfg.sysProxy !== null
}

async function safeWriteConfig(content: string): Promise<void> {
  const configPath = appConfigPath()
  const tmpPath = `${configPath}.tmp`
  const backupPath = `${configPath}.backup`

  try {
    await writeFile(tmpPath, content, 'utf-8')
    if (existsSync(configPath)) {
      await copyFile(configPath, backupPath)
      if (process.platform === 'win32') {
        await unlink(configPath)
      }
    }
    if (existsSync(tmpPath)) {
      await rename(tmpPath, configPath)
    }
  } catch (e) {
    if (existsSync(tmpPath)) {
      try {
        await unlink(tmpPath)
      } catch {
        // ignore
      }
    }
    throw e
  }
}

export async function getAppConfig(force = false): Promise<AppConfig> {
  if (force || !appConfig) {
    try {
      const data = await readFile(appConfigPath(), 'utf-8')
      const parsed = parseYaml<AppConfig>(data)
      if (!parsed || !isValidConfig(parsed)) {
        const backup = await readFile(`${appConfigPath()}.backup`, 'utf-8')
        appConfig = parseYaml<AppConfig>(backup)
      } else {
        appConfig = parsed
      }
    } catch (e) {
      appConfig = defaultConfig
    }
  }
  if (typeof appConfig !== 'object') appConfig = defaultConfig
  appConfig = applyBuildConfig(appConfig)
  return appConfig
}

export async function patchAppConfig(patch: Partial<AppConfig>): Promise<AppConfig> {
  const previousPromise = writePromise
  const currentPromise = (async () => {
    await previousPromise
    const nextConfig = applyBuildConfig(deepMerge(structuredClone(appConfig), patch))
    await safeWriteConfig(stringifyYaml(nextConfig))
    appConfig = nextConfig
  })()
  writePromise = currentPromise.catch(() => {})
  await currentPromise
  notifyConfigOperation('patchAppConfig', patch)
  return appConfig
}

export function getAppConfigSync(): AppConfig {
  try {
    const raw = readFileSync(appConfigPath(), 'utf-8')
    const data = parseYaml<AppConfig>(raw)
    if (typeof data === 'object' && data !== null) {
      return applyBuildConfig(data)
    }
    return applyBuildConfig(defaultConfig)
  } catch (e) {
    return applyBuildConfig(defaultConfig)
  }
}
