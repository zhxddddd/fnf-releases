import { Spinner, Button, Label, Modal, Switch } from '@heroui/react'

import React, { useEffect, useState } from 'react'
import { BaseEditor } from '../base/base-editor-lazy'
import { getProfileStr, setProfileStr } from '@renderer/utils/ipc'
import { useNavigate } from 'react-router-dom'
import { useAppConfig } from '@renderer/hooks/use-app-config'
import { notify } from '@renderer/utils/notification'
import ConfirmModal from '../base/base-confirm'

interface Props {
  id: string
  isRemote: boolean
  onClose: () => void
}

const EditFileModal: React.FC<Props> = (props) => {
  const { id, isRemote, onClose } = props
  useAppConfig()
  const [currData, setCurrData] = useState('')
  const [originalData, setOriginalData] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [loadedId, setLoadedId] = useState<string | null>(null)
  const [loadAttempt, setLoadAttempt] = useState(0)
  const [isSaving, setIsSaving] = useState(false)
  const [isDiff, setIsDiff] = useState(false)
  const [sideBySide, setSideBySide] = useState(false)
  const [isConfirmOpen, setIsConfirmOpen] = useState(false)
  const navigate = useNavigate()

  const isModified = currData !== originalData
  const canSave = !isLoading && loadedId === id && !isSaving

  const handleClose = (): void => {
    if (isModified) {
      setIsConfirmOpen(true)
    } else {
      onClose()
    }
  }

  const save = async (): Promise<void> => {
    if (!canSave) return
    setIsSaving(true)
    try {
      await setProfileStr(id, currData)
      onClose()
    } catch (e) {
      notify(e, { variant: 'danger' })
    } finally {
      setIsSaving(false)
    }
  }

  useEffect(() => {
    let canceled = false
    setIsLoading(true)
    setLoadedId(null)
    setCurrData('')
    setOriginalData('')
    const getContent = async (): Promise<void> => {
      try {
        const data = await getProfileStr(id)
        if (canceled) return
        setCurrData(data)
        setOriginalData(data)
        setLoadedId(id)
      } catch (e) {
        if (!canceled) notify(e, { variant: 'danger' })
      } finally {
        if (!canceled) setIsLoading(false)
      }
    }
    void getContent()
    return () => {
      canceled = true
    }
  }, [id, loadAttempt])

  return (
    <Modal>
      {isConfirmOpen && (
        <ConfirmModal
          title="确认取消"
          description="您有未保存的修改，确定要取消吗？"
          confirmText="放弃修改"
          cancelText="继续编辑"
          onChange={setIsConfirmOpen}
          onConfirm={onClose}
        />
      )}
      <Modal.Backdrop
        isOpen={true}
        onOpenChange={handleClose}
        variant="blur"
        className="top-12 h-[calc(100%-48px)]"
      >
        <Modal.Container scroll="inside">
          <Modal.Dialog className="mt-4 h-[calc(100%-32px)] max-w-none w-[calc(100%-100px)]">
            <Modal.Header className="app-drag pb-0">
              <div className="flex justify-start">
                <Modal.Heading className="flex items-center">编辑订阅</Modal.Heading>
                {isRemote && (
                  <small className="ml-2 text-foreground-500">
                    注意：此处编辑配置更新订阅后会还原，如需要自定义配置请使用
                    <Button
                      size="sm"
                      variant="ghost"
                      className="app-nodrag"
                      onPress={() => {
                        navigate('/override')
                      }}
                    >
                      覆写
                    </Button>
                    功能
                  </small>
                )}
              </div>
            </Modal.Header>
            <Modal.Body className="h-full">
              {isLoading ? (
                <div className="flex h-full items-center justify-center">
                  <Spinner size="lg" color="accent" />
                </div>
              ) : loadedId !== id ? (
                <div className="flex h-full flex-col items-center justify-center gap-3">
                  <p>读取配置失败，无法编辑或保存</p>
                  <Button onPress={() => setLoadAttempt((attempt) => attempt + 1)}>重试</Button>
                </div>
              ) : (
                <BaseEditor
                  language="yaml"
                  value={currData}
                  originalValue={isDiff ? originalData : undefined}
                  onChange={(value) => setCurrData(value)}
                  diffRenderSideBySide={sideBySide}
                />
              )}
            </Modal.Body>
            <Modal.Footer className="flex justify-between pt-0 pb-0">
              <div className="flex items-center space-x-2">
                <Switch size="sm" isSelected={isDiff} onChange={setIsDiff} aria-label="启用">
                  <Switch.Content>
                    <Switch.Control>
                      <Switch.Thumb />
                    </Switch.Control>
                    <Label>显示修改</Label>
                  </Switch.Content>
                </Switch>
                <Switch
                  size="sm"
                  isSelected={sideBySide}
                  onChange={setSideBySide}
                  aria-label="启用"
                >
                  <Switch.Content>
                    <Switch.Control>
                      <Switch.Thumb />
                    </Switch.Control>
                    <Label>侧边显示</Label>
                  </Switch.Content>
                </Switch>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="secondary" onPress={handleClose}>
                  取消
                </Button>
                <Button
                  size="sm"
                  variant="primary"
                  isDisabled={!canSave}
                  isPending={isSaving}
                  onPress={() => save()}
                >
                  保存
                </Button>
              </div>
            </Modal.Footer>
            <Modal.CloseTrigger className="app-nodrag" />
          </Modal.Dialog>
        </Modal.Container>
      </Modal.Backdrop>
    </Modal>
  )
}

export default EditFileModal
