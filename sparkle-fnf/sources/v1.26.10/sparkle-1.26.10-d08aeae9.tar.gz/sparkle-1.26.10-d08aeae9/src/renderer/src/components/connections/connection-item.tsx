import { Button, Card, Chip, Avatar } from '@heroui/react'
import { Pressable } from 'react-aria'

import { calcTraffic } from '@renderer/utils/calc'
import dayjs from 'dayjs'
import React, { memo, useCallback, useEffect, useMemo, useState } from 'react'
import { CgClose, CgTrash } from 'react-icons/cg'

interface Props {
  index: number
  info: ControllerConnectionDetail
  displayIcon?: boolean
  iconUrl: string
  displayName?: string
  hideProcess?: boolean
  selected: ControllerConnectionDetail | undefined
  setSelected: React.Dispatch<React.SetStateAction<ControllerConnectionDetail | undefined>>
  setIsDetailModalOpen: React.Dispatch<React.SetStateAction<boolean>>
  close: (id: string) => void
}

const ConnectionItemComponent: React.FC<Props> = ({
  index,
  info,
  displayIcon,
  iconUrl,
  displayName,
  hideProcess,
  close,
  setSelected,
  setIsDetailModalOpen
}) => {
  const fallbackProcessName = useMemo(
    () => info.metadata.process?.replace(/\.exe$/, '') || info.metadata.sourceIP,
    [info.metadata.process, info.metadata.sourceIP]
  )
  const processName = displayName || fallbackProcessName

  const destination = useMemo(
    () =>
      info.metadata.host ||
      info.metadata.sniffHost ||
      info.metadata.destinationIP ||
      info.metadata.remoteDestination,
    [
      info.metadata.host,
      info.metadata.sniffHost,
      info.metadata.destinationIP,
      info.metadata.remoteDestination
    ]
  )

  const [timeAgo, setTimeAgo] = useState(() => dayjs(info.start).fromNow())

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeAgo(dayjs(info.start).fromNow())
    }, 60000)

    return () => clearInterval(timer)
  }, [info.start])

  const uploadTraffic = useMemo(() => calcTraffic(info.upload), [info.upload])

  const downloadTraffic = useMemo(() => calcTraffic(info.download), [info.download])

  const uploadSpeed = useMemo(
    () => (info.uploadSpeed ? calcTraffic(info.uploadSpeed) : null),
    [info.uploadSpeed]
  )

  const downloadSpeed = useMemo(
    () => (info.downloadSpeed ? calcTraffic(info.downloadSpeed) : null),
    [info.downloadSpeed]
  )

  const hasSpeed = useMemo(
    () => Boolean(info.uploadSpeed || info.downloadSpeed),
    [info.uploadSpeed, info.downloadSpeed]
  )

  const handleCardPress = useCallback(() => {
    setSelected(info)
    setIsDetailModalOpen(true)
  }, [info, setSelected, setIsDetailModalOpen])

  const handleClose = useCallback(() => {
    close(info.id)
  }, [close, info.id])

  return (
    <div className={`px-2 pb-1 ${index === 0 ? 'pt-1' : ''}`} style={{ minHeight: 68 }}>
      <Pressable onPress={handleCardPress}>
        <Card className="w-full" data-pressable="true" role="button" tabIndex={0}>
          <div className="w-full flex justify-between items-center">
            {displayIcon && (
              <div>
                <Avatar size="lg" className="bg-transparent ml-2 w-14 h-14">
                  <Avatar.Image src={iconUrl} />
                </Avatar>
              </div>
            )}
            <div
              className={`w-full flex flex-col justify-start truncate relative ${displayIcon ? '-ml-2' : ''}`}
            >
              <Card.Header className="relative flex items-center gap-1 pt-2 pr-12 pb-0">
                <div className="ml-2 flex-1 text-ellipsis whitespace-nowrap overflow-hidden text-left">
                  <span style={{ textAlign: 'left' }}>
                    {hideProcess ? destination : `${processName} → ${destination}`}
                  </span>
                </div>
                <small className="ml-2 whitespace-nowrap text-foreground-500">{timeAgo}</small>
                <Button
                  isIconOnly
                  size="sm"
                  aria-label={info.isActive ? '关闭连接' : '删除记录'}
                  onPress={handleClose}
                  variant="ghost"
                  data-color={info.isActive ? 'warning' : 'danger'}
                  className="absolute right-2 transform"
                >
                  {info.isActive ? (
                    <CgClose className="text-lg" />
                  ) : (
                    <CgTrash className="text-lg" />
                  )}
                </Button>
              </Card.Header>
              <Card.Footer className="pt-1 pb-2">
                <div className="flex gap-1 overflow-x-auto no-scrollbar">
                  <Chip
                    size="sm"
                    data-color={info.isActive ? 'primary' : 'danger'}
                    variant="tertiary"
                    data-dot="true"
                    data-radius="sm"
                  >
                    <span className="chip__dot" aria-hidden="true" />
                    <Chip.Label>
                      {info.metadata.type}({info.metadata.network.toUpperCase()})
                    </Chip.Label>
                  </Chip>
                  <Chip
                    size="sm"
                    data-color="default"
                    variant="tertiary"
                    data-outline="true"
                    data-radius="sm"
                    className={['flag-emoji whitespace-nowrap overflow-hidden']
                      .filter(Boolean)
                      .join(' ')}
                  >
                    <Chip.Label>{info.chains[0]}</Chip.Label>
                  </Chip>
                  <Chip
                    size="sm"
                    data-color="default"
                    variant="tertiary"
                    data-outline="true"
                    data-radius="sm"
                  >
                    <Chip.Label>
                      ↑ {uploadTraffic}↓ {downloadTraffic}
                    </Chip.Label>
                  </Chip>
                  {hasSpeed && (
                    <Chip
                      size="sm"
                      data-color="primary"
                      variant="tertiary"
                      data-outline="true"
                      data-radius="sm"
                    >
                      <Chip.Label>
                        ↑ {uploadSpeed || '0 B'}/s ↓ {downloadSpeed || '0 B'}/s
                      </Chip.Label>
                    </Chip>
                  )}
                </div>
              </Card.Footer>
            </div>
          </div>
        </Card>
      </Pressable>
    </div>
  )
}

const ConnectionItem = memo(ConnectionItemComponent, (prevProps, nextProps) => {
  return (
    prevProps.info.id === nextProps.info.id &&
    prevProps.info.upload === nextProps.info.upload &&
    prevProps.info.download === nextProps.info.download &&
    prevProps.info.uploadSpeed === nextProps.info.uploadSpeed &&
    prevProps.info.downloadSpeed === nextProps.info.downloadSpeed &&
    prevProps.info.isActive === nextProps.info.isActive &&
    prevProps.iconUrl === nextProps.iconUrl &&
    prevProps.displayIcon === nextProps.displayIcon &&
    prevProps.displayName === nextProps.displayName &&
    prevProps.hideProcess === nextProps.hideProcess &&
    prevProps.selected?.id === nextProps.selected?.id
  )
})

export default ConnectionItem
