import { Button } from '@heroui/react'

import BasePage from '@renderer/components/base/base-page'
// import { CgWebsite } from 'react-icons/cg'
import { IoLogoGithub } from 'react-icons/io5'
import WebdavConfig from '@renderer/components/settings/webdav-config'
import GeneralConfig from '@renderer/components/settings/general-config'
import AdvancedSettings from '@renderer/components/settings/advanced-settings'
import Actions from '@renderer/components/settings/actions'
import ShortcutConfig from '@renderer/components/settings/shortcut-config'
import { FaTelegramPlane } from 'react-icons/fa'
import SiderConfig from '@renderer/components/settings/sider-config'
import SubStoreConfig from '@renderer/components/settings/substore-config'
import AppearanceConfig from '@renderer/components/settings/appearance-confis'
import WebhookConfigPanel from '@renderer/components/settings/webhook-config'

const Settings: React.FC = () => {
  return (
    <BasePage
      title="应用设置"
      header={
        <>
          {/* <Button
              isIconOnly
              size="sm"
              variant="light"
              title="官方文档"
              className="app-nodrag"
              onPress={() => {
                window.open('https://')
              }}
            >
              <CgWebsite className="text-lg" />
            </Button> */}
          <Button
            isIconOnly
            size="sm"
            onPress={() => {
              window.open('https://github.com/xishang0128/sparkle')
            }}
            variant="ghost"
            data-color="default"
            className="app-nodrag"
          >
            <IoLogoGithub className="text-lg" />
          </Button>
          <Button
            isIconOnly
            size="sm"
            onPress={() => {
              window.open('https://t.me/atri0828')
            }}
            variant="ghost"
            data-color="default"
            className="app-nodrag"
          >
            <FaTelegramPlane className="text-lg" />
          </Button>
        </>
      }
    >
      <GeneralConfig />
      <AppearanceConfig />
      <SubStoreConfig />
      <SiderConfig />
      <WebdavConfig />
      <WebhookConfigPanel />
      <AdvancedSettings />
      <ShortcutConfig />
      <Actions />
    </BasePage>
  )
}

export default Settings
