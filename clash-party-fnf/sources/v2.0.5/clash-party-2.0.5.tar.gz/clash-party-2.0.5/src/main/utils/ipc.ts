import path from 'path'
import v8 from 'v8'
import { readFile } from 'fs/promises'
import { app, ipcMain } from 'electron'
import i18next from 'i18next'
import {
  mihomoChangeProxy,
  mihomoCloseAllConnections,
  mihomoCloseConnection,
  mihomoGroupDelay,
  mihomoGroups,
  mihomoProxies,
  mihomoProxyDelay,
  mihomoProxyProviders,
  mihomoRuleProviders,
  mihomoRules,
  mihomoUnfixedProxy,
  mihomoUpdateProxyProviders,
  mihomoUpdateRuleProviders,
  mihomoUpgrade,
  mihomoUpgradeGeo,
  mihomoUpgradeUI,
  mihomoHotReloadConfig,
  mihomoVersion,
  patchMihomoConfig,
  mihomoSmartGroupWeights,
  mihomoSmartFlushCache,
  mihomoRulesDisable
} from '../core/mihomoApi'
import { checkAutoRun, disableAutoRun, enableAutoRun } from '../sys/autoRun'
import {
  getAppConfig,
  patchAppConfig,
  getControledMihomoConfig,
  patchControledMihomoConfig,
  getProfileConfig,
  getCurrentProfileItem,
  getProfileItem,
  addProfileItem,
  removeProfileItem,
  changeCurrentProfile,
  getProfileStr,
  getProfileImportInfo,
  getFileStr,
  setFileStr,
  setProfileStr,
  updateProfileItem,
  setProfileConfig,
  getOverrideConfig,
  setOverrideConfig,
  getOverrideItem,
  addOverrideItem,
  removeOverrideItem,
  getOverride,
  setOverride,
  updateOverrideItem,
  convertMrsRuleset
} from '../config'
import {
  startSubStoreFrontendServer,
  startSubStoreBackendServer,
  stopSubStoreFrontendServer,
  stopSubStoreBackendServer,
  downloadSubStore,
  subStoreFrontendPort,
  subStorePort
} from '../resolve/server'
import {
  quitWithoutCore,
  restartCore,
  checkTunPermissions,
  grantTunPermissions,
  manualGrantCorePermition,
  checkAdminPrivileges,
  restartAsAdmin,
  checkMihomoCorePermissions,
  requestTunPermissions,
  checkHighPrivilegeCore,
  showTunPermissionDialog,
  showErrorDialog
} from '../core/manager'
import { triggerSysProxy } from '../sys/sysproxy'
import { checkUpdate, downloadAndInstallUpdate } from '../resolve/autoUpdater'
import {
  getFilePath,
  openFile,
  openUWPTool,
  readImageFileDataURL,
  readTextFile,
  resetAppConfig,
  setNativeTheme,
  setupFirewall
} from '../sys/misc'
import { getRuntimeConfig, getRuntimeConfigStr } from '../core/factory'
import {
  localSwitchNeedsDnsConfirm,
  setControlDns,
  takeDnsOverrideAutoDisabledNotice
} from '../core/dnsOverrideGuard'
import { getSmartModelStatus, downloadSmartModel } from '../core/smartModel'
import {
  listWebdavBackups,
  webdavBackup,
  webdavDelete,
  webdavRestore,
  exportLocalBackup,
  importLocalBackup,
  reinitScheduler
} from '../resolve/backup'
import { getInterfaces } from '../sys/interface'
import {
  closeTrayIcon,
  copyEnv,
  getTrayTrafficStyle,
  showTrayIcon,
  updateTrayIcon,
  updateTrayIconImmediate
} from '../resolve/tray'
import { registerShortcut } from '../resolve/shortcut'
import { closeMainWindow, mainWindow, showMainWindow, triggerMainWindow } from '../window'
import {
  applyTheme,
  fetchThemes,
  importThemes,
  readTheme,
  resolveThemes,
  writeTheme
} from '../resolve/theme'
import { subStoreCollections, subStoreSubs } from '../core/subStoreApi'
import { exportGistAgeSecretKey, generateGistAgeKeyPair, getGistUrl } from '../resolve/gistApi'
import { startMonitor } from '../resolve/trafficMonitor'
import { closeFloatingWindow, showContextMenu, showFloatingWindow } from '../resolve/floatingWindow'
import { addProfileUpdater, removeProfileUpdater } from '../core/profileUpdater'
import {
  previewPlugin,
  installPlugin,
  loginPlugin,
  removePlugin,
  updatePluginProfile,
  patchPluginItem
} from '../resolve/plugin'
import { getPluginConfig } from '../config/plugin'
import {
  clearTrafficUsage,
  importTrafficUsage,
  queryTrafficUsageBreakdown,
  queryTrafficUsageOverview
} from '../traffic/database'
import {
  getLocalConfig,
  getLocalNode,
  createLocalNodes,
  saveLocalNode,
  removeLocalNode,
  getLocalProxyGroup,
  getLocalRulesEditor,
  saveLocalRules,
  saveLocalRuleProvider,
  createLocalProxyGroup,
  saveLocalProxyGroup,
  removeLocalProxyGroup,
  reorderLocalProxyGroups,
  saveLocalDraft,
  previewLocalConfig,
  publishLocalConfig,
  exportLocalConfig,
  refreshLocalSource,
  removeLocalSource
} from '../local/service'
import { getImageDataURL } from './image'
import { get as httpGet } from './chromeRequest'
import { getAppInfo } from './app-info'
import { logDir, rulePath } from './dirs'
import { installMihomoCore, getGitHubTags, clearVersionCache } from './github'
import { atomicWriteFile } from './safeFile'
import { startSubStoreServices } from './init'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AsyncFn = (...args: any[]) => Promise<any>
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type SyncFn = (...args: any[]) => any

function wrapAsync<T extends AsyncFn>(
  fn: T
): (...args: Parameters<T>) => Promise<ReturnType<T> | { invokeError: unknown }> {
  return async (...args) => {
    try {
      return await fn(...args)
    } catch (e) {
      if (e && typeof e === 'object' && 'message' in e) {
        return { invokeError: e.message }
      }
      return { invokeError: typeof e === 'string' ? e : 'Unknown Error' }
    }
  }
}

function registerHandlers(handlers: Record<string, AsyncFn | SyncFn>, async = true): void {
  for (const [channel, handler] of Object.entries(handlers)) {
    if (async) {
      ipcMain.handle(channel, (_e, ...args) => wrapAsync(handler as AsyncFn)(...args))
    } else {
      ipcMain.handle(channel, (_e, ...args) => (handler as SyncFn)(...args))
    }
  }
}

async function fetchMihomoTags(
  forceRefresh = false
): Promise<{ name: string; zipball_url: string; tarball_url: string }[]> {
  return await getGitHubTags('MetaCubeX', 'mihomo', forceRefresh)
}

async function installSpecificMihomoCore(version: string): Promise<void> {
  clearVersionCache('MetaCubeX', 'mihomo')
  return await installMihomoCore(version)
}

async function clearMihomoVersionCache(): Promise<void> {
  clearVersionCache('MetaCubeX', 'mihomo')
}

async function getRuleStr(id: string): Promise<string> {
  return await readFile(rulePath(id), 'utf-8')
}

async function setRuleStr(id: string, str: string): Promise<void> {
  await atomicWriteFile(rulePath(id), str, { encoding: 'utf8' })
}

async function getSmartOverrideContent(): Promise<string | null> {
  try {
    const override = await getOverrideItem('smart-core-override')
    return override?.file || null
  } catch {
    return null
  }
}

async function fetchIPInfo(url: string): Promise<unknown> {
  const res = await httpGet<unknown>(url, { timeout: 10000, responseType: 'json' })
  return res.data
}

async function measureLatency(url: string): Promise<number | null> {
  try {
    const t0 = Date.now()
    await httpGet<unknown>(url, { timeout: 5000, responseType: 'text' })
    return Date.now() - t0
  } catch {
    return null
  }
}

async function changeLanguage(lng: string): Promise<void> {
  await i18next.changeLanguage(lng)
  ipcMain.emit('updateTrayMenu')
}

async function setTitleBarOverlay(overlay: Electron.TitleBarOverlayOptions): Promise<void> {
  if (mainWindow && typeof mainWindow.setTitleBarOverlay === 'function') {
    mainWindow.setTitleBarOverlay(overlay)
  }
}

const asyncHandlers: Record<string, AsyncFn> = {
  // Mihomo API
  mihomoVersion,
  mihomoCloseConnection,
  mihomoCloseAllConnections,
  mihomoRules,
  mihomoRulesDisable,
  queryTrafficUsageOverview,
  queryTrafficUsageBreakdown,
  importTrafficUsage,
  clearTrafficUsage,
  mihomoProxies,
  mihomoGroups,
  mihomoProxyProviders,
  mihomoUpdateProxyProviders,
  mihomoRuleProviders,
  mihomoUpdateRuleProviders,
  mihomoChangeProxy,
  mihomoUnfixedProxy,
  mihomoUpgradeGeo,
  mihomoUpgrade,
  mihomoUpgradeUI,
  mihomoProxyDelay,
  mihomoGroupDelay,
  patchMihomoConfig,
  mihomoSmartGroupWeights,
  mihomoSmartFlushCache,
  // AutoRun
  checkAutoRun,
  enableAutoRun,
  disableAutoRun,
  // Config
  getAppConfig,
  patchAppConfig,
  getControledMihomoConfig,
  patchControledMihomoConfig,
  setControlDns,
  takeDnsOverrideAutoDisabledNotice,
  // Profile
  localSwitchNeedsDnsConfirm,
  getProfileConfig,
  setProfileConfig,
  getCurrentProfileItem,
  getProfileItem,
  getProfileStr,
  getProfileImportInfo,
  setProfileStr,
  addProfileItem,
  removeProfileItem,
  updateProfileItem,
  changeCurrentProfile,
  addProfileUpdater,
  removeProfileUpdater,
  // Override
  getOverrideConfig,
  setOverrideConfig,
  getOverrideItem,
  addOverrideItem,
  removeOverrideItem,
  updateOverrideItem,
  getOverride,
  setOverride,
  // File
  getFileStr,
  setFileStr,
  convertMrsRuleset,
  getRuntimeConfig,
  getRuntimeConfigStr,
  getSmartOverrideContent,
  getRuleStr,
  setRuleStr,
  getLocalConfig,
  getLocalNode,
  createLocalNodes,
  saveLocalNode,
  removeLocalNode,
  getLocalProxyGroup,
  getLocalRulesEditor,
  saveLocalRules,
  saveLocalRuleProvider,
  createLocalProxyGroup,
  saveLocalProxyGroup,
  removeLocalProxyGroup,
  reorderLocalProxyGroups,
  saveLocalDraft,
  previewLocalConfig,
  publishLocalConfig,
  exportLocalConfig,
  refreshLocalSource,
  removeLocalSource,
  readTextFile,
  // Core
  restartCore,
  getSmartModelStatus,
  downloadSmartModel,
  mihomoHotReloadConfig,
  startMonitor,
  quitWithoutCore,
  // System
  triggerSysProxy,
  checkTunPermissions,
  grantTunPermissions,
  manualGrantCorePermition,
  checkAdminPrivileges,
  restartAsAdmin,
  checkMihomoCorePermissions,
  requestTunPermissions,
  checkHighPrivilegeCore,
  showTunPermissionDialog,
  showErrorDialog,
  openUWPTool,
  setupFirewall,
  copyEnv,
  // Update
  checkUpdate,
  downloadAndInstallUpdate,
  fetchMihomoTags,
  installSpecificMihomoCore,
  clearMihomoVersionCache,
  // Backup
  webdavBackup,
  webdavRestore,
  listWebdavBackups,
  webdavDelete,
  reinitWebdavBackupScheduler: reinitScheduler,
  exportLocalBackup,
  importLocalBackup,
  // SubStore
  startSubStoreFrontendServer,
  stopSubStoreFrontendServer,
  startSubStoreBackendServer,
  stopSubStoreBackendServer,
  ensureSubStoreServices: startSubStoreServices,
  downloadSubStore,
  subStoreSubs,
  subStoreCollections,
  // Theme
  resolveThemes,
  fetchThemes,
  importThemes,
  readTheme,
  writeTheme,
  applyTheme,
  // Tray
  showTrayIcon,
  closeTrayIcon,
  updateTrayIcon,
  getTrayTrafficStyle,
  // Floating Window
  showFloatingWindow,
  closeFloatingWindow,
  showContextMenu,
  // Plugin
  getPluginConfig,
  previewPlugin,
  installPlugin,
  loginPlugin,
  removePlugin,
  updatePluginProfile,
  patchPluginItem,
  // Misc
  getGistUrl,
  generateGistAgeKeyPair,
  exportGistAgeSecretKey,
  fetchIPInfo,
  measureLatency,
  getImageDataURL,
  readImageFileDataURL,
  getAppInfo,
  changeLanguage,
  setTitleBarOverlay,
  registerShortcut
}

const syncHandlers: Record<string, SyncFn> = {
  resetAppConfig,
  getFilePath,
  openFile,
  getInterfaces,
  setNativeTheme,
  getVersion: () => app.getVersion(),
  platform: () => process.platform,
  subStorePort: () => subStorePort,
  subStoreFrontendPort: () => subStoreFrontendPort,
  updateTrayIconImmediate,
  showMainWindow,
  closeMainWindow,
  triggerMainWindow,
  setAlwaysOnTop: (alwaysOnTop: boolean) => mainWindow?.setAlwaysOnTop(alwaysOnTop),
  isAlwaysOnTop: () => mainWindow?.isAlwaysOnTop(),
  openDevTools: () => mainWindow?.webContents.openDevTools(),
  createHeapSnapshot: () => v8.writeHeapSnapshot(path.join(logDir(), `${Date.now()}.heapsnapshot`)),
  relaunchApp: () => {
    app.relaunch()
    app.quit()
  },
  quitApp: () => app.quit()
}

const confirmationRequiredHandlers = new Set([
  'closeMainWindow',
  'downloadAndInstallUpdate',
  'importLocalBackup',
  'installSpecificMihomoCore',
  'openFile',
  'quitApp',
  'quitWithoutCore',
  'relaunchApp',
  'removeLocalNode',
  'removeLocalProxyGroup',
  'removeLocalSource',
  'removeOverrideItem',
  'removePlugin',
  'removeProfileItem',
  'resetAppConfig',
  'restartAsAdmin',
  'setupFirewall',
  'webdavDelete'
])

const mcpExposedHandlers = new Set([
  'getAppConfig',
  'patchAppConfig',
  'getControledMihomoConfig',
  'patchControledMihomoConfig',
  'setControlDns',
  'getProfileConfig',
  'getCurrentProfileItem',
  'getProfileItem',
  'getProfileStr',
  'getProfileImportInfo',
  'setProfileStr',
  'addProfileItem',
  'removeProfileItem',
  'updateProfileItem',
  'changeCurrentProfile',
  'getOverrideConfig',
  'getOverrideItem',
  'addOverrideItem',
  'removeOverrideItem',
  'updateOverrideItem',
  'getOverride',
  'setOverride',
  'getRuntimeConfig',
  'getRuntimeConfigStr',
  'getRuleStr',
  'setRuleStr',
  'getLocalConfig',
  'getLocalNode',
  'getLocalProxyGroup',
  'getLocalRulesEditor',
  'previewLocalConfig',
  'mihomoVersion',
  'mihomoCloseConnection',
  'mihomoCloseAllConnections',
  'mihomoRules',
  'mihomoRulesDisable',
  'mihomoProxies',
  'mihomoGroups',
  'mihomoProxyProviders',
  'mihomoUpdateProxyProviders',
  'mihomoRuleProviders',
  'mihomoUpdateRuleProviders',
  'mihomoChangeProxy',
  'mihomoUnfixedProxy',
  'mihomoProxyDelay',
  'mihomoGroupDelay',
  'patchMihomoConfig',
  'mihomoHotReloadConfig',
  'mihomoSmartGroupWeights',
  'mihomoSmartFlushCache',
  'restartCore'
])

export interface IpcCapability {
  name: string
  kind: 'async' | 'sync'
  requiresConfirmation: boolean
}

export const ipcCapabilities: IpcCapability[] = [
  ...Object.keys(asyncHandlers).map((name) => ({
    name,
    kind: 'async' as const,
    requiresConfirmation: confirmationRequiredHandlers.has(name)
  })),
  ...Object.keys(syncHandlers).map((name) => ({
    name,
    kind: 'sync' as const,
    requiresConfirmation: confirmationRequiredHandlers.has(name)
  }))
]

export const mcpCapabilities = ipcCapabilities.filter((capability) =>
  mcpExposedHandlers.has(capability.name)
)

export async function invokeIpcHandler(name: string, args: unknown[]): Promise<unknown> {
  const handler = asyncHandlers[name] ?? syncHandlers[name]
  if (!handler) throw new Error(`Unknown IPC capability: ${name}`)
  return await (handler as (...args: unknown[]) => unknown)(...args)
}

export function ipcHandlerRequiresConfirmation(name: string): boolean {
  return confirmationRequiredHandlers.has(name)
}

export function registerIpcMainHandlers(): void {
  registerHandlers(asyncHandlers, true)
  registerHandlers(syncHandlers, false)
}
