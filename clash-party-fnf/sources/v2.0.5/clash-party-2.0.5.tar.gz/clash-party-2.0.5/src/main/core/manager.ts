import { ChildProcess, execFile, spawn } from 'child_process'
import { randomUUID } from 'crypto'
import { readFile, mkdir, rm, writeFile } from 'fs/promises'
import { promisify } from 'util'
import { setTimeout as delay } from 'timers/promises'
import path from 'path'
import os from 'os'
import { existsSync, watch, type FSWatcher as NodeFSWatcher } from 'fs'
import chokidar, { type FSWatcher as ChokidarWatcher } from 'chokidar'
import { app, dialog, ipcMain } from 'electron'
import { mainWindow } from '../window'
import {
  getAppConfig,
  getControledMihomoConfig,
  getProfileItem,
  patchControledMihomoConfig,
  manageSmartOverride
} from '../config'
import {
  dataDir,
  coreLogPath,
  mihomoCoreDir,
  mihomoCorePath,
  mihomoProfileWorkDir,
  mihomoTestDir,
  mihomoWorkConfigPath,
  mihomoWorkDir
} from '../utils/dirs'
import { uploadRuntimeConfigIfChanged } from '../resolve/gistApi'
import { startMonitor } from '../resolve/trafficMonitor'
import { isLocalProfile } from '../../shared/local-config'
import { ensureRuntimeFiles, safeShowErrorBox } from '../utils/init'
import { parseAgeSecretKeys } from '../utils/age'
import i18next from '../../shared/i18n'
import { managerLogger } from '../utils/logger'
import { createCoreLogWritableStream } from '../utils/logFile'
import { dismissNotification, showNotification } from '../utils/notification'
import {
  startMihomoTraffic,
  startMihomoConnections,
  startMihomoLogs,
  startMihomoMemory,
  stopMihomoConnections,
  stopMihomoTraffic,
  stopMihomoLogs,
  stopMihomoMemory,
  patchMihomoConfig,
  mihomoHotReloadConfig,
  getAxios
} from './mihomoApi'
import { generateProfile, getRuntimeConfig } from './factory'
import { syncControlDnsAfterApply, type DnsOverrideGuardResult } from './dnsOverrideGuard'
import { syncSmartModelToTestDir } from './smartModel'
import {
  checkAdminRestartForTun as checkAdminRestartForTunWithRestart,
  getSessionAdminStatus,
  setStopCoreBeforeAdminRestart
} from './permissions'
import {
  cleanupSocketFile,
  cleanupWindowsNamedPipes,
  validateWindowsPipeAccess,
  waitForCoreReady,
  verifyProcessOwner
} from './process'
import { setPublicDNS, recoverDNS } from './dns'
import { parseTailscaleLog } from './tailscale-auth'

// 重新导出权限相关函数
export {
  initAdminStatus,
  getSessionAdminStatus,
  checkAdminPrivileges,
  checkMihomoCorePermissions,
  checkHighPrivilegeCore,
  grantTunPermissions,
  restartAsAdmin,
  waitForAdminRestartSource,
  requestTunPermissions,
  showTunPermissionDialog,
  showErrorDialog,
  checkTunPermissions,
  manualGrantCorePermition
} from './permissions'

export { getDefaultDevice } from './dns'

const execFilePromise = promisify(execFile)
const ctlParam = process.platform === 'win32' ? '-ext-ctl-pipe' : '-ext-ctl-unix'
const coreHookTimeout = 30000
const automaticRestartDelay = 750
// macOS 释放 utun 通常需要 1-2 秒；等待 3 秒后再升级为 SIGKILL，
// 避免新核心启动时旧核心仍占用虚拟网卡。
const coreShutdownTimeout = 3000
const resumeReloadDelay = 5000
// 同一次失败内核可能连打多行，10 秒内只提示一次，避免弹窗刷屏
const tunFailureReportInterval = 10000
const coreProcessNames = ['mihomo', 'mihomo-alpha', 'mihomo-smart'] as const
const tailscaleAuthNotificationKeyPrefix = 'tailscale-auth:'
const directCoreLogLineLimit = 16 * 1024

// 核心进程状态
interface CoreProcessWatchdog {
  process: ChildProcess
  corePid: number
}

let child: ChildProcess | null = null
let coreProcessWatchdog: CoreProcessWatchdog | null = null
let isRestarting = false
let coreOperationPhase: 'initializing' | 'ready' | 'blocked' | 'shutting-down' = 'ready'
let coreOperationTail: Promise<void> = Promise.resolve()
let pendingRestart: Promise<void> | null = null
let cancelActiveStartup: ((reason: Error) => void) | null = null
let automaticRestartController: AbortController | null = null
let resumeReloadTimer: NodeJS.Timeout | null = null
const notifiedTailscaleAuthKeys = new Set<string>()
const tailscaleAuthKeysByName = new Map<string, Set<string>>()
let directCoreLogLineBuffer = ''

// 文件监听器
let coreWatcher: ChokidarWatcher | null = null

type CoreStartupMode = 'log' | 'post-up'

interface CoreStartupHook {
  hookDir: string
  upFile: string
  upFileName: string
  postUpCommand: string
  postDownCommand: string
}

interface CoreHookWaiter {
  promise: Promise<void>
  attachProcess: (process: ChildProcess) => void
}

export function hasCoreProcess(): boolean {
  return Boolean(child && !child.killed && child.exitCode === null && child.signalCode === null)
}

export function beginCoreInitialization(): void {
  coreOperationPhase = 'initializing'
}

export function completeCoreInitialization(canStart: boolean): void {
  if (coreOperationPhase !== 'shutting-down') {
    coreOperationPhase = canStart ? 'ready' : 'blocked'
  }
}

function ensureCoreOperationAllowed(): void {
  if (coreOperationPhase === 'initializing') {
    throw new Error('Core is still initializing')
  }
  if (coreOperationPhase === 'blocked') {
    throw new Error('Core startup is unavailable because startup safety checks did not pass')
  }
  if (coreOperationPhase === 'shutting-down') {
    throw new Error('Core startup was cancelled because the application is shutting down')
  }
}

function ensureNotShuttingDown(): void {
  if (coreOperationPhase === 'shutting-down') {
    throw new Error('Core startup was cancelled because the application is shutting down')
  }
}

function runCoreOperation<T>(operation: () => Promise<T>): Promise<T> {
  const current = coreOperationTail.then(operation, operation)
  coreOperationTail = current.then(
    () => undefined,
    () => undefined
  )
  return current
}

function cancelAutomaticRestart(): void {
  automaticRestartController?.abort()
  automaticRestartController = null
}

function stopCoreProcessWatchdog(corePid?: number): void {
  const watchdog = coreProcessWatchdog
  if (!watchdog || (corePid !== undefined && watchdog.corePid !== corePid)) return

  coreProcessWatchdog = null
  if (watchdog.process.pid) {
    try {
      process.kill(-watchdog.process.pid, 'SIGKILL')
    } catch {
      // The watchdog has already exited.
    }
  }
  watchdog.process.stdin?.destroy()
}

function startCoreProcessWatchdog(proc: ChildProcess, detached: boolean): void {
  if (process.platform !== 'linux' || detached || !proc.pid) return

  stopCoreProcessWatchdog()

  const corePid = proc.pid
  const watchdogProcess = spawn(
    'sh',
    ['-c', 'cat >/dev/null; kill -9 "$1" 2>/dev/null', 'mihomo-core-watchdog', `${corePid}`],
    {
      stdio: ['pipe', 'ignore', 'ignore'],
      detached: true
    }
  )
  coreProcessWatchdog = { process: watchdogProcess, corePid }

  const watchdogStdin = watchdogProcess.stdin as typeof watchdogProcess.stdin & {
    unref?: () => void
  }
  watchdogStdin.unref?.()
  watchdogProcess.unref()

  watchdogProcess.once('error', (error) => {
    if (coreProcessWatchdog?.process === watchdogProcess) {
      coreProcessWatchdog = null
    }
    watchdogProcess.stdin.destroy()
    managerLogger.warn('Failed to start core process watchdog', error)
  })
  watchdogProcess.once('exit', (code, signal) => {
    if (coreProcessWatchdog?.process !== watchdogProcess) return

    coreProcessWatchdog = null
    managerLogger.warn(
      `Core process watchdog exited unexpectedly, code: ${code}, signal: ${signal}`
    )
  })
}

function shellQuote(value: string): string {
  return `'${value.replace(/'/g, "'\\''")}'`
}

function notifyTailscaleLog(line: string): void {
  const event = parseTailscaleLog(line)
  if (!event) return

  if (event.type === 'done') {
    clearTailscaleAuthNotifications(event.name)
    return
  }

  const { name, url } = event.request
  const id = `${tailscaleAuthNotificationKeyPrefix}${url}`
  if (notifiedTailscaleAuthKeys.has(id)) return

  notifiedTailscaleAuthKeys.add(id)
  const keys = tailscaleAuthKeysByName.get(name) ?? new Set<string>()
  keys.add(id)
  tailscaleAuthKeysByName.set(name, keys)

  showNotification({
    id,
    title: i18next.t('common.notification.tailscaleAuthTitle', { name }),
    body: i18next.t('common.notification.tailscaleAuthBody'),
    persistent: true,
    url
  })
}

function handleDirectCoreLogData(data: Buffer | string): void {
  const text = data.toString().replaceAll('\r\n', '\n')
  const combined = directCoreLogLineBuffer + text
  const lines = combined.split('\n')

  if (combined.endsWith('\n')) {
    directCoreLogLineBuffer = ''
  } else {
    directCoreLogLineBuffer = lines.pop() ?? ''
    if (directCoreLogLineBuffer.length > directCoreLogLineLimit) {
      directCoreLogLineBuffer = directCoreLogLineBuffer.slice(-directCoreLogLineLimit)
    }
  }

  for (const line of lines) {
    notifyTailscaleLog(line)
  }
}

function flushDirectCoreLogNotifications(): void {
  if (!directCoreLogLineBuffer) return

  notifyTailscaleLog(directCoreLogLineBuffer)
  directCoreLogLineBuffer = ''
}

function clearTailscaleAuthNotifications(name?: string): void {
  const keys = name
    ? tailscaleAuthKeysByName.get(name)
    : new Set(
        Array.from(notifiedTailscaleAuthKeys).filter((key) =>
          key.startsWith(tailscaleAuthNotificationKeyPrefix)
        )
      )
  if (!keys) return

  for (const key of keys) {
    notifiedTailscaleAuthKeys.delete(key)
    dismissNotification(key)
  }

  if (name) tailscaleAuthKeysByName.delete(name)
  else tailscaleAuthKeysByName.clear()
}

function hookTouchCommand(file: string): string {
  return process.platform === 'win32' ? `type nul > ${file}` : `: > ${shellQuote(file)}`
}

function coreHookDir(): string {
  if (process.platform === 'win32' && process.env.ProgramData) {
    return path.join(process.env.ProgramData, 'mihomo-party', 'core-hooks')
  }

  return path.join(dataDir(), 'core-hooks')
}

async function createCoreStartupHook(): Promise<CoreStartupHook> {
  const runId = randomUUID()
  const hookDir = coreHookDir()

  await rm(hookDir, { recursive: true, force: true })
  await mkdir(hookDir, { recursive: true })

  const upFileName = `${runId}.up`
  const downFileName = `${runId}.down`
  const upFile = path.join(hookDir, upFileName)
  const downFile = path.join(hookDir, downFileName)

  return {
    hookDir,
    upFile,
    upFileName,
    postUpCommand: hookTouchCommand(upFile),
    postDownCommand: hookTouchCommand(downFile)
  }
}

function createCoreHookWaiter(hook: CoreStartupHook): CoreHookWaiter {
  let watcher: NodeFSWatcher | undefined
  let timer: NodeJS.Timeout | undefined
  let attachedProcess: ChildProcess | undefined
  let completed = false

  let resolvePromise: () => void
  let rejectPromise: (reason?: unknown) => void

  const cleanup = (): void => {
    if (timer) {
      clearTimeout(timer)
      timer = undefined
    }
    if (watcher) {
      watcher.close()
      watcher = undefined
    }
    if (attachedProcess) {
      attachedProcess.off('close', handleClose)
      attachedProcess = undefined
    }
  }

  const complete = (error?: unknown): void => {
    if (completed) return
    completed = true
    cleanup()
    if (error) {
      rejectPromise(error)
    } else {
      resolvePromise()
    }
  }

  const handleClose = (code: number | null, signal: NodeJS.Signals | null): void => {
    complete(new Error(`Core startup failed before post-up, code: ${code}, signal: ${signal}`))
  }

  const promise = new Promise<void>((resolve, reject) => {
    resolvePromise = resolve
    rejectPromise = reject

    watcher = watch(hook.hookDir, (_eventType, filename) => {
      const changedFile = filename?.toString()
      if (changedFile === hook.upFileName || (!changedFile && existsSync(hook.upFile))) {
        complete()
      }
    })

    watcher.on('error', complete)

    timer = setTimeout(() => {
      complete(new Error(`Timed out waiting for core post-up: ${coreHookTimeout}ms`))
    }, coreHookTimeout)
  })

  return {
    promise,
    attachProcess: (process) => {
      attachedProcess = process
      attachedProcess.once('close', handleClose)
    }
  }
}

async function stopPidFileCore(): Promise<void> {
  const pidPath = path.join(dataDir(), 'core.pid')
  if (!existsSync(pidPath)) return

  const pidString = await readFile(pidPath, 'utf-8').catch(() => '')
  const pid = parseInt(pidString.trim())
  if (!isNaN(pid)) {
    try {
      if (await verifyProcessOwner(pid, coreProcessNames)) {
        process.kill(pid, 'SIGINT')
        const deadline = Date.now() + coreShutdownTimeout
        let stillRunning = true
        while (stillRunning && Date.now() < deadline) {
          await delay(50)
          try {
            process.kill(pid, 0)
          } catch {
            stillRunning = false
          }
        }
        if (stillRunning) {
          try {
            process.kill(pid, 'SIGKILL')
          } catch {
            // ignore
          }
        }
      } else {
        managerLogger.info(`PID ${pid} is not a known mihomo process, skipping kill`)
      }
    } catch {
      // ignore
    }
  }

  await rm(pidPath).catch(() => {})
}

// 初始化核心文件监听
export function initCoreWatcher(): void {
  if (coreWatcher) return

  coreWatcher = chokidar.watch(path.join(mihomoCoreDir(), 'meta-update'), {})
  coreWatcher.on('unlinkDir', async () => {
    // 等待核心自我更新完成，避免与核心自动重启产生竞态
    await new Promise((resolve) => setTimeout(resolve, 3000))
    try {
      await restartCore(true)
    } catch (e) {
      safeShowErrorBox('mihomo.error.coreStartFailed', `${e}`)
    }
  })

  // 监听 restartCore 事件（用于 DNS 状态恢复等场景，避免循环依赖）
  ipcMain.removeAllListeners('restartCore')
  ipcMain.on('restartCore', async () => {
    await restartCore()
    mainWindow?.webContents.send('appConfigUpdated')
  })
}

// 清理核心文件监听
export function cleanupCoreWatcher(): void {
  if (coreWatcher) {
    coreWatcher.close()
    coreWatcher = null
  }
}

// 动态生成 IPC 路径
export const getMihomoIpcPath = (): string => {
  if (process.platform === 'win32') {
    const isAdmin = getSessionAdminStatus()
    const sessionId = process.env.SESSIONNAME || process.env.USERNAME || 'default'
    const processId = process.pid

    return isAdmin
      ? `\\\\.\\pipe\\MihomoParty\\mihomo-admin-${sessionId}-${processId}`
      : `\\\\.\\pipe\\MihomoParty\\mihomo-user-${sessionId}-${processId}`
  }

  const uid = process.getuid?.() || 'unknown'
  const processId = process.pid
  return `/tmp/mihomo-party-${uid}-${processId}.sock`
}

// 核心配置接口
interface CoreConfig {
  corePath: string
  workDir: string
  safePath?: string
  ipcPath: string
  logLevel: LogLevel
  tunEnabled: boolean
  autoSetDNS: boolean
  cpuPriority: string
  ageSecretKey?: string
  detached: boolean
  startupMode: CoreStartupMode
  startupHook?: CoreStartupHook
  dnsGuard: DnsOverrideGuardResult
}

function buildCoreEnv(safePath?: string, ageSecretKey?: string): NodeJS.ProcessEnv {
  const env = { ...process.env }
  const normalizedAgeSecretKey = parseAgeSecretKeys(ageSecretKey).join('\n')
  if (normalizedAgeSecretKey) {
    env.CLASH_AGE_SECRET_KEY = normalizedAgeSecretKey
  }
  if (!safePath) return env

  const existingSafePaths = env.SAFE_PATHS?.split(path.delimiter).filter(Boolean) ?? []
  env.SAFE_PATHS = existingSafePaths.includes(safePath)
    ? existingSafePaths.join(path.delimiter)
    : [...existingSafePaths, safePath].join(path.delimiter)
  return env
}

// 准备核心配置
async function prepareCore(detached: boolean, skipStop = false): Promise<CoreConfig> {
  await ensureRuntimeFiles()

  const [appConfig, mihomoConfig] = await Promise.all([getAppConfig(), getControledMihomoConfig()])

  let { diffWorkDir = false } = appConfig
  const {
    core = 'mihomo',
    autoSetDNS = true,
    mihomoCpuPriority = 'PRIORITY_NORMAL',
    coreStartupMode = 'log',
    testProfileOnStart = true
  } = appConfig

  let { 'log-level': logLevel = 'info' as LogLevel, tun } = mihomoConfig

  // 清理轻量模式遗留的后台核心
  await stopPidFileCore()

  // 管理 Smart 内核覆写配置
  await manageSmartOverride()

  // generateProfile 返回实际使用的 current
  const { profileId: current, dnsGuard } = await generateProfile()
  const currentItem = await getProfileItem(current)
  if (isLocalProfile(currentItem)) {
    diffWorkDir = false
    const localRuntime = await getRuntimeConfig()
    logLevel = localRuntime['log-level'] || 'info'
    tun = localRuntime.tun
  }
  const ageSecretKey = currentItem?.ageSecretKey || ''
  if (testProfileOnStart) {
    await checkProfile(current, core, diffWorkDir, ageSecretKey)
  }
  if (!skipStop && hasCoreProcess()) {
    await stopCoreInternal()
  }
  await cleanupSocketFile()

  // 设置 DNS
  if (tun?.enable && autoSetDNS) {
    ensureNotShuttingDown()
    try {
      await setPublicDNS()
    } catch (error) {
      managerLogger.error('set dns failed', error)
    }
    ensureNotShuttingDown()
  }

  // 获取动态 IPC 路径
  const ipcPath = getMihomoIpcPath()
  managerLogger.info(`Using IPC path: ${ipcPath}`)

  if (process.platform === 'win32') {
    await validateWindowsPipeAccess(ipcPath)
  }

  const startupMode: CoreStartupMode = coreStartupMode === 'post-up' ? 'post-up' : 'log'
  const startupHook =
    !detached && startupMode === 'post-up' ? await createCoreStartupHook() : undefined

  return {
    corePath: mihomoCorePath(core),
    workDir: diffWorkDir ? mihomoProfileWorkDir(current) : mihomoWorkDir(),
    safePath: diffWorkDir ? mihomoWorkDir() : undefined,
    ipcPath,
    logLevel,
    tunEnabled: tun?.enable ?? false,
    autoSetDNS,
    cpuPriority: mihomoCpuPriority,
    ageSecretKey,
    detached,
    startupMode,
    startupHook,
    dnsGuard
  }
}

// 启动核心进程
function spawnCoreProcess(config: CoreConfig): ChildProcess {
  const {
    corePath,
    workDir,
    safePath,
    ipcPath,
    cpuPriority,
    ageSecretKey,
    detached,
    startupMode,
    startupHook
  } = config

  const args = ['-d', workDir, ctlParam, ipcPath]
  if (startupHook) {
    args.push('-post-up', startupHook.postUpCommand, '-post-down', startupHook.postDownCommand)
    managerLogger.info(`Core startup mode: post-up, post-up command: ${startupHook.postUpCommand}`)
  } else if (!detached) {
    managerLogger.info(`Core startup mode: ${startupMode}`)
  }

  const proc = spawn(corePath, args, {
    detached,
    stdio: detached ? 'ignore' : undefined,
    env: buildCoreEnv(safePath, ageSecretKey)
  })

  if (process.platform === 'win32' && proc.pid) {
    os.setPriority(
      proc.pid,
      os.constants.priority[cpuPriority as keyof typeof os.constants.priority]
    )
  }

  if (!detached) {
    const stdout = createCoreLogWritableStream(coreLogPath)
    const stderr = createCoreLogWritableStream(coreLogPath)
    proc.stdout?.pipe(stdout)
    proc.stderr?.pipe(stderr)
    proc.stdout?.on('data', handleDirectCoreLogData)
    proc.stderr?.on('data', handleDirectCoreLogData)
    proc.once('close', flushDirectCoreLogNotifications)
  }

  return proc
}

// 设置核心进程事件监听
function setupCoreListeners(
  proc: ChildProcess,
  config: CoreConfig,
  hookWaiter: CoreHookWaiter | undefined,
  resolve: (value: Promise<void>[]) => void,
  reject: (reason: unknown) => void
): void {
  const { logLevel, startupMode } = config
  let startupSettled = false
  const startupTimer =
    startupMode === 'log'
      ? setTimeout(() => {
          rejectStartup(new Error(`Timed out waiting for core API readiness: ${coreHookTimeout}ms`))
        }, coreHookTimeout)
      : undefined

  const resolveStartup = (value: Promise<void>[]): void => {
    if (startupSettled) return
    startupSettled = true
    if (startupTimer) clearTimeout(startupTimer)
    resolve(value)
  }

  const rejectStartup = (reason: unknown): void => {
    if (startupSettled) return
    startupSettled = true
    if (startupTimer) clearTimeout(startupTimer)
    if (child === proc) {
      child = null
      proc.kill('SIGTERM')
      stopCoreProcessWatchdog(proc.pid)
    }
    reject(reason)
  }

  const startMihomoApiStreams = async (): Promise<void> => {
    await waitForCoreReady()
    await getAxios(true)
    await Promise.all([
      startMihomoTraffic(),
      startMihomoConnections(),
      startMihomoLogs(),
      startMihomoMemory()
    ])
  }

  const completeCoreStartup = async (): Promise<void> => {
    try {
      await uploadRuntimeConfigIfChanged()
    } catch (error) {
      managerLogger.warn('Failed to sync runtime config to Gist', error)
    }
    try {
      await patchMihomoConfig({ 'log-level': logLevel })
    } finally {
      mainWindow?.webContents.send('groupsUpdated')
      mainWindow?.webContents.send('rulesUpdated')
    }
  }

  proc.once('error', (error) => {
    managerLogger.error('Core process error', error)
    rejectStartup(new Error(`Failed to start core process: ${error.message}`))
  })

  proc.on('close', async (code, signal) => {
    managerLogger.info(`Core closed, code: ${code}, signal: ${signal}`)
    stopCoreProcessWatchdog(proc.pid)

    if (child === proc) {
      child = null
    }

    if (coreOperationPhase === 'shutting-down') {
      rejectStartup(new Error('Core closed because the application is shutting down'))
      return
    }

    if (isRestarting) {
      managerLogger.info('Core closed during restart, skipping auto-restart')
      rejectStartup(new Error('Core startup was interrupted by restart'))
      return
    }

    if (coreOperationPhase === 'ready') {
      managerLogger.info('Try Restart Core after unexpected exit')
      try {
        await restartCoreAfterUnexpectedExit()
        resolveStartup([])
      } catch (error) {
        managerLogger.error('Automatic core recovery failed', error)
        rejectStartup(error)
      }
    } else {
      await runCoreOperation(() => stopCoreInternal())
      rejectStartup(new Error(`Core exited before startup completed, code: ${code}`))
    }
  })

  let lastTunFailureAt = 0

  proc.stdout?.on('data', async (data) => {
    const str = data.toString()

    // TUN 权限错误
    if (str.includes('configure tun interface: operation not permitted')) {
      lastTunFailureAt = Date.now()
      patchControledMihomoConfig({ tun: { enable: false } })
      mainWindow?.webContents.send('controledMihomoConfigUpdated')
      ipcMain.emit('updateTrayMenu')
      rejectStartup(i18next.t('tun.error.tunPermissionDenied'))
      return
    }

    // 其它虚拟网卡创建失败：内核只打印 "Start TUN listening error" 并在 ReCreateTun 的 defer 里
    // 把 tun.enable 置回 false，自身继续运行，界面却仍显示虚拟网卡已开启，
    // 用户只能看到"开了没效果"。把内核原始错误反馈出来，并同步关掉开关。
    const tunListenErrorLine = str
      .split('\n')
      .find((line: string) => line.includes('Start TUN listening error'))
    if (tunListenErrorLine && Date.now() - lastTunFailureAt > tunFailureReportInterval) {
      lastTunFailureAt = Date.now()
      managerLogger.error('TUN listening error detected:', tunListenErrorLine.trim())
      try {
        await patchControledMihomoConfig({ tun: { enable: false } })
      } catch (error) {
        managerLogger.warn('Failed to disable TUN after listening error', error)
      }
      mainWindow?.webContents.send('controledMihomoConfigUpdated')
      ipcMain.emit('updateTrayMenu')
      // 不能用 showErrorBox/showMessageBoxSync：模态框会卡住主进程，内核 stdout 写满后会一起卡死
      dialog
        .showMessageBox({
          type: 'error',
          title: i18next.t('tun.error.tunStartFailed'),
          message: i18next.t('tun.error.tunStartFailed'),
          detail: tunListenErrorLine.trim()
        })
        .catch(() => {})
      return
    }

    // 控制器监听错误
    const isControllerError =
      (process.platform !== 'win32' && str.includes('External controller unix listen error')) ||
      (process.platform === 'win32' && str.includes('External controller pipe listen error'))

    if (isControllerError) {
      managerLogger.error('External controller listen error detected:', str)

      if (process.platform === 'win32') {
        managerLogger.info('Attempting Windows pipe cleanup and retry...')
        try {
          await cleanupWindowsNamedPipes(true)
          await new Promise((r) => setTimeout(r, 2000))
        } catch (cleanupError) {
          managerLogger.error('Pipe cleanup failed:', cleanupError)
        }
      }

      rejectStartup(i18next.t('mihomo.error.externalControllerListenError'))
      return
    }

    if (startupMode === 'post-up') {
      return
    }

    // API 就绪
    const isApiReady =
      (process.platform !== 'win32' && str.includes('RESTful API unix listening at')) ||
      (process.platform === 'win32' && str.includes('RESTful API pipe listening at'))

    if (isApiReady) {
      resolveStartup([
        new Promise((innerResolve) => {
          proc.stdout?.on('data', async (innerData) => {
            if (
              innerData
                .toString()
                .toLowerCase()
                .includes('start initial compatible provider default')
            ) {
              completeCoreStartup()
                .then(() => innerResolve())
                .catch((error) => {
                  managerLogger.warn('Failed to complete core startup', error)
                  innerResolve()
                })
            }
          })
        })
      ])

      await startMihomoApiStreams()
    }
  })

  if (startupMode === 'post-up') {
    if (!hookWaiter) {
      rejectStartup(new Error('Core post-up startup mode requires a startup hook'))
      return
    }

    hookWaiter.promise
      .then(async () => {
        managerLogger.info('Core post-up hook triggered')
        await startMihomoApiStreams()
        resolveStartup([completeCoreStartup()])
      })
      .catch(rejectStartup)
  }

  cancelActiveStartup = (reason) => rejectStartup(reason)
}

interface CoreStartAttempt {
  readiness: Promise<Promise<void>[]>
}

async function startCoreInternal(detached = false, skipStop = false): Promise<CoreStartAttempt> {
  ensureNotShuttingDown()
  clearTailscaleAuthNotifications()
  directCoreLogLineBuffer = ''
  const config = await prepareCore(detached, skipStop)
  ensureNotShuttingDown()
  const hookWaiter = config.startupHook ? createCoreHookWaiter(config.startupHook) : undefined
  const proc = spawnCoreProcess(config)
  hookWaiter?.attachProcess(proc)
  child = proc
  startCoreProcessWatchdog(proc, detached)

  if (detached) {
    managerLogger.info(
      `Core process detached successfully on ${process.platform}, PID: ${proc.pid}`
    )
    proc.unref()
    return { readiness: Promise.resolve([new Promise(() => {})]) }
  }

  const readiness = new Promise<Promise<void>[]>((resolve, reject) => {
    setupCoreListeners(proc, config, hookWaiter, resolve, reject)
  }).then(async (value) => {
    // API 就绪后同步本次 DNS 保护结果。
    try {
      await syncControlDnsAfterApply(config.dnsGuard)
    } catch (error) {
      managerLogger.warn('Failed to sync DNS override state after core start', error)
    }
    return value
  })
  const activeCancel = cancelActiveStartup
  readiness.then(
    () => {
      if (cancelActiveStartup === activeCancel) cancelActiveStartup = null
    },
    () => {
      if (cancelActiveStartup === activeCancel) cancelActiveStartup = null
    }
  )

  return {
    readiness
  }
}

// 互斥只覆盖 prepare/spawn；API-ready 等待在队列外进行，避免 close handler 自重启死锁。
function queueCoreStart(detached = false, skipStop = false): Promise<Promise<void>[]> {
  return runCoreOperation(async () => {
    ensureNotShuttingDown()
    if (!detached && !skipStop && hasCoreProcess()) {
      return { readiness: Promise.resolve<Promise<void>[]>([]) }
    }
    return startCoreInternal(detached, skipStop)
  }).then((attempt) => attempt.readiness)
}

export function startCore(detached = false, skipStop = false): Promise<Promise<void>[]> {
  ensureCoreOperationAllowed()
  return queueCoreStart(detached, skipStop)
}

// 启动期唯一的例外入口：安全检查通过后由主流程调用，仍受退出状态保护。
export function startCoreForStartup(): Promise<Promise<void>[]> {
  if (coreOperationPhase === 'blocked') {
    throw new Error('Core startup is unavailable because startup safety checks did not pass')
  }
  ensureNotShuttingDown()
  return queueCoreStart()
}

async function stopCoreInternal(force = false, cancelStartup = true): Promise<void> {
  if (!force && process.platform === 'darwin') {
    try {
      await recoverDNS()
    } catch (error) {
      managerLogger.error('recover dns failed', error)
    }
  }

  const stoppedChild = stopCoreProcessAndStreams(cancelStartup)

  try {
    await ensureCoreProcessExited(stoppedChild)
  } catch (error) {
    managerLogger.error(
      `Core PID ${stoppedChild?.pid ?? 'unknown'} refused to exit within ${coreShutdownTimeout}ms`,
      error
    )
  }

  await cleanupStoppedCoreResources()
}

function stopCoreProcessAndStreams(
  cancelStartup = true,
  keepWatchdog = false
): ChildProcess | null {
  if (cancelStartup) {
    cancelActiveStartup?.(new Error('Core startup was cancelled by a stop request'))
    cancelActiveStartup = null
  }
  const stoppedChild = child
  if (child) {
    child.removeAllListeners()
    try {
      child.kill('SIGINT')
    } catch (error) {
      managerLogger.warn(`Failed to send SIGINT to core PID ${child.pid ?? 'unknown'}`, error)
    }
    child = null
  }

  if (!keepWatchdog) stopCoreProcessWatchdog()

  stopMihomoTraffic()
  stopMihomoConnections()
  stopMihomoLogs()
  stopMihomoMemory()

  return stoppedChild
}

async function cleanupStoppedCoreResources(): Promise<void> {
  try {
    await getAxios(true)
  } catch (error) {
    managerLogger.warn('Failed to refresh axios instance:', error)
  }

  await stopPidFileCore()
  await cleanupSocketFile()
}

export async function stopCore(force = false): Promise<void> {
  ensureCoreOperationAllowed()
  cancelAutomaticRestart()
  return runCoreOperation(() => stopCoreInternal(force))
}

// 退出不排队等待启动/重启完成：先同步终止子进程，再做有界清理。
// SIGINT 之后必须确认核心真的退出：core.pid 只在轻量模式写入，普通运行时
// stopPidFileCore 是空操作，没有任何 SIGKILL 兜底。核心若在退出预算内没走完
// （例如 TUN 拆除慢），主进程 app.exit() 后它就成了孤儿进程。
// Linux watchdog 也要留到确认退出之后再撤，否则最后一道兜底先于核心消失。
export async function stopCoreForExit(): Promise<void> {
  coreOperationPhase = 'shutting-down'
  cancelAutomaticRestart()
  const stoppedChild = stopCoreProcessAndStreams(true, true)
  await Promise.allSettled([
    recoverDNS({ force: true, timeout: 750 }),
    cleanupStoppedCoreResources(),
    // 确认退出后才撤 watchdog；确认失败时留着它，让它在主进程退出时补 kill -9。
    ensureCoreProcessExited(stoppedChild).then(() => stopCoreProcessWatchdog(stoppedChild?.pid))
  ])
}

setStopCoreBeforeAdminRestart(stopCore)

async function ensureCoreProcessExited(proc: ChildProcess | null): Promise<void> {
  if (!proc) return

  const waitForExit = async (): Promise<boolean> => {
    const deadline = Date.now() + coreShutdownTimeout
    while (proc.exitCode === null && proc.signalCode === null && Date.now() < deadline) {
      await delay(50)
    }
    return proc.exitCode !== null || proc.signalCode !== null
  }

  if (await waitForExit()) return
  managerLogger.warn(`Core PID ${proc.pid ?? 'unknown'} did not exit after SIGINT; sending SIGKILL`)
  proc.kill('SIGKILL')
  if (!(await waitForExit())) {
    throw new Error(`Core PID ${proc.pid ?? 'unknown'} is still running after SIGKILL`)
  }
}

async function restartCoreOnce(forceStop: boolean): Promise<void> {
  const startAttempt = await runCoreOperation(async () => {
    await stopCoreInternal(forceStop)
    return startCoreInternal(false, true)
  })
  await startAttempt.readiness
}

function trackCoreRestart(operation: () => Promise<void>): Promise<void> {
  if (pendingRestart) return pendingRestart

  isRestarting = true
  const restart = operation().finally(() => {
    isRestarting = false
    if (pendingRestart === restart) pendingRestart = null
  })
  pendingRestart = restart
  return restart
}

async function restartCoreAfterUnexpectedExit(): Promise<void> {
  ensureCoreOperationAllowed()
  const controller = new AbortController()
  automaticRestartController = controller
  try {
    await trackCoreRestart(async () => {
      try {
        await restartCoreOnce(true)
      } catch (error) {
        if (controller.signal.aborted || coreOperationPhase === 'shutting-down') throw error

        managerLogger.warn('Automatic core restart failed (attempt 1/2), retrying', error)
        await delay(automaticRestartDelay, undefined, { signal: controller.signal })
        await restartCoreOnce(true)
      }
    })
  } finally {
    if (automaticRestartController === controller) automaticRestartController = null
  }
}

export function restartCore(forceStop = false): Promise<void> {
  ensureCoreOperationAllowed()
  return trackCoreRestart(() => restartCoreOnce(forceStop))
}

// 系统挂起会带走 TUN 网卡上的路由和 DNS 劫持规则：唤醒后内核进程还在、HTTP 代理端口
// 也还在，但 TUN 的 DNS 劫持已经不响应（#1231 报告者用 dig 复现过），于是浏览器拿到真实
// 解析结果，表现为「挂久了就没网」（#159）。用户的手动解法是去 DNS 设置里存一次，
// 那条路径走的就是 mihomoHotReloadConfig ——内核侧 executor.ApplyConfig 会重跑
// updateDNS / updateTun / updateIPTables 并 resolver.ResetConnection()，规则随之重建。
// 这里在 resume 后自动做同一件事，省去用户手动开关。
async function reloadCoreAfterResume(): Promise<void> {
  if (!hasCoreProcess()) return
  const { tun } = await getControledMihomoConfig()
  if (!tun?.enable) return

  await mihomoHotReloadConfig()
  managerLogger.info('Reloaded core config after system resume')
}

export function handleSystemResume(): void {
  if (resumeReloadTimer) clearTimeout(resumeReloadTimer)
  // 唤醒瞬间物理网卡通常还没重新连上，auto-detect-interface 会认到错误的出口，
  // 等一小会儿再重载。
  resumeReloadTimer = setTimeout(() => {
    resumeReloadTimer = null
    reloadCoreAfterResume().catch((error) => {
      managerLogger.warn('Failed to reload core config after system resume', error)
    })
  }, resumeReloadDelay)
}

export function cancelSystemResumeReload(): void {
  if (!resumeReloadTimer) return
  clearTimeout(resumeReloadTimer)
  resumeReloadTimer = null
}

// 保持核心运行
export async function keepCoreAlive(): Promise<boolean> {
  try {
    await startCore(true)
    if (child?.pid) {
      await writeFile(path.join(dataDir(), 'core.pid'), child.pid.toString())
    }
    return Boolean(child?.pid)
  } catch (e) {
    safeShowErrorBox('mihomo.error.coreStartFailed', `${e}`)
    return false
  }
}

// 退出但保持核心运行
export async function quitWithoutCore(): Promise<void> {
  managerLogger.info(`Starting lightweight mode on platform: ${process.platform}`)
  if (!(await keepCoreAlive())) return
  await startMonitor(true)
  managerLogger.info('Exiting main process, core will continue running in background')
  app.exit()
}

// 检查配置文件
async function checkProfile(
  current: string | undefined,
  core: string = 'mihomo',
  diffWorkDir: boolean = false,
  ageSecretKey?: string
): Promise<void> {
  await checkProfileConfig(
    diffWorkDir ? mihomoWorkConfigPath(current) : mihomoWorkConfigPath('work'),
    core,
    ageSecretKey
  )
}

export interface CheckProfileOptions {
  workDir?: string
  // 调用方的预算 signal：中止后校验子进程被终止，校验按失败处理（调用方不得再写入）
  signal?: AbortSignal
  // 校验子进程的硬上限（毫秒）：防止一次 `-t` 无限期占住调用方持有的锁
  timeoutMs?: number
}

export async function checkProfileConfig(
  configPath: string,
  core: string = 'mihomo',
  ageSecretKey?: string,
  opts: CheckProfileOptions = {}
): Promise<void> {
  const corePath = mihomoCorePath(core)
  await syncSmartModelToTestDir()

  try {
    await execFilePromise(
      corePath,
      ['-t', '-f', configPath, '-d', opts.workDir ?? mihomoTestDir()],
      {
        env: buildCoreEnv(undefined, ageSecretKey),
        signal: opts.signal,
        timeout: opts.timeoutMs
      }
    )
  } catch (error) {
    managerLogger.error('Profile check failed', error)

    if (error instanceof Error && 'stdout' in error) {
      const { stdout, stderr } = error as { stdout: string; stderr?: string }
      managerLogger.info('Profile check stdout', stdout)
      managerLogger.info('Profile check stderr', stderr)

      const errorLines = stdout
        .split('\n')
        .filter((line) => line.includes('level=error') || line.includes('error'))
        .map((line) => {
          if (line.includes('level=error')) {
            return line.split('level=error')[1]?.trim() || line
          }
          return line.trim()
        })
        .filter((line) => line.length > 0)

      if (errorLines.length === 0) {
        const allLines = stdout.split('\n').filter((line) => line.trim().length > 0)
        // 内核根本没能启动时（动态链接失败、缺符号、架构不匹配）只有 stderr 有内容，
        // stdout 为空，此前拼出来的是一句没有任何原因的“配置检查失败”。
        const detailLines =
          allLines.length > 0
            ? allLines
            : (stderr ?? '').split('\n').filter((line) => line.trim().length > 0)
        throw new Error(
          `${i18next.t('mihomo.error.profileCheckFailed')}:\n${detailLines.join('\n')}`
        )
      } else {
        throw new Error(
          `${i18next.t('mihomo.error.profileCheckFailed')}:\n${errorLines.join('\n')}`
        )
      }
    } else {
      throw new Error(`${i18next.t('mihomo.error.profileCheckFailed')}: ${error}`)
    }
  }
}

// 权限检查入口（从 permissions.ts 调用）
export async function checkAdminRestartForTun(): Promise<void> {
  await checkAdminRestartForTunWithRestart(restartCore)
}
