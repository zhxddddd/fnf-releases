import { Button, Card, CardBody, CardFooter } from '@heroui/react'
import { toast } from '@renderer/components/base/toast'
import { calcTraffic } from '@renderer/utils/calc'
import { mihomoVersion, restartCore } from '@renderer/utils/ipc'
import React, { useEffect, useState } from 'react'
import { IoMdRefresh } from 'react-icons/io'
import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { useLocation } from 'react-router-dom'
import PubSub from 'pubsub-js'
import useSWR from 'swr'
import { useAppConfig } from '@renderer/hooks/use-app-config'
import { LuCpu } from 'react-icons/lu'
import { useTranslation } from 'react-i18next'
import SiderItem from './sider-item'

interface Props {
  iconOnly?: boolean
  expanded?: boolean
}

const MihomoCoreCard: React.FC<Props> = (props) => {
  const { appConfig } = useAppConfig()
  const { iconOnly, expanded } = props
  const { mihomoCoreCardStatus = 'col-span-2', disableAnimations = false } = appConfig || {}
  const { data: version, mutate } = useSWR('mihomoVersion', mihomoVersion)
  const location = useLocation()
  const match = location.pathname.includes('/mihomo')
  const {
    attributes,
    listeners,
    setNodeRef,
    transform: tf,
    transition,
    isDragging
  } = useSortable({
    id: 'mihomo'
  })
  const transform = tf ? { x: tf.x, y: tf.y, scaleX: 1, scaleY: 1 } : null
  const [mem, setMem] = useState(0)
  const [restarting, setRestarting] = useState(false)
  const { t } = useTranslation()

  useEffect(() => {
    const token = PubSub.subscribe('mihomo-core-changed', () => {
      mutate()
    })
    const onMemory = (_e: unknown, ...args: unknown[]): void => {
      const info = args[0] as IMihomoMemoryInfo
      setMem(info.inuse)
    }
    const unsubscribeMemory = window.electron.ipcRenderer.on('mihomoMemory', onMemory)
    return (): void => {
      PubSub.unsubscribe(token)
      unsubscribeMemory()
    }
  }, [mutate])

  if (iconOnly) {
    return (
      <SiderItem
        className={mihomoCoreCardStatus}
        title={t('sider.cards.core')}
        route="/mihomo"
        icon={<LuCpu className="text-[20px]" />}
        expanded={expanded}
      />
    )
  }

  return (
    <div
      style={{
        position: 'relative',
        transform: CSS.Transform.toString(transform),
        transition,
        zIndex: isDragging ? 'calc(infinity)' : undefined
      }}
      className={`${mihomoCoreCardStatus} min-w-0 mihomo-core-card`}
    >
      {mihomoCoreCardStatus === 'col-span-2' ? (
        <Card
          fullWidth
          ref={setNodeRef}
          {...attributes}
          {...listeners}
          className={`${match ? 'bg-primary' : 'hover:bg-primary/30'} ${disableAnimations ? '' : `motion-reduce:transition-transform-background ${isDragging ? 'scale-[0.95] tap-highlight-transparent' : ''}`}`}
        >
          <CardBody>
            <div
              ref={setNodeRef}
              {...attributes}
              {...listeners}
              className="flex min-w-0 items-center justify-between gap-2 h-[32px]"
            >
              <h3
                title={version?.version}
                className={`min-w-0 flex-1 truncate text-md font-bold leading-[32px] ${match ? 'text-primary-foreground' : 'text-foreground'}`}
              >
                {version?.version ?? '-'}
              </h3>

              <Button
                isIconOnly
                size="sm"
                variant="light"
                color="default"
                className="shrink-0"
                title={t('mihomo.restart')}
                disabled={restarting}
                onPress={async () => {
                  setRestarting(true)
                  try {
                    await restartCore()
                  } catch (e) {
                    toast.error(String(e))
                  } finally {
                    mutate()
                    setRestarting(false)
                  }
                }}
              >
                <IoMdRefresh
                  className={`${match ? 'text-primary-foreground' : 'text-foreground'} text-[24px] ${restarting ? 'animate-spin' : ''}`}
                />
              </Button>
            </div>
          </CardBody>
          <CardFooter className="pt-1">
            <div
              className={`flex justify-between w-full text-md font-bold ${match ? 'text-primary-foreground' : 'text-foreground'}`}
            >
              <h4>{t('sider.cards.core')}</h4>
              <h4>{calcTraffic(mem)}</h4>
            </div>
          </CardFooter>
        </Card>
      ) : (
        <Card
          fullWidth
          ref={setNodeRef}
          {...attributes}
          {...listeners}
          className={`${match ? 'bg-primary' : 'hover:bg-primary/30'} ${disableAnimations ? '' : `motion-reduce:transition-transform-background ${isDragging ? 'scale-[0.95] tap-highlight-transparent' : ''}`}`}
        >
          <CardBody className="pb-1 pt-0 px-0">
            <div className="flex justify-between">
              <Button
                isIconOnly
                className="bg-transparent pointer-events-none"
                variant="flat"
                color="default"
              >
                <LuCpu
                  color="default"
                  className={`${match ? 'text-primary-foreground' : 'text-foreground'} text-[24px] font-bold`}
                />
              </Button>
              <Button
                isIconOnly
                size="sm"
                variant="light"
                color="default"
                className="mr-2 mt-2"
                title={t('mihomo.restart')}
                disabled={restarting}
                onPress={async () => {
                  setRestarting(true)
                  try {
                    await restartCore()
                  } catch (e) {
                    toast.error(String(e))
                  } finally {
                    mutate()
                    setRestarting(false)
                  }
                }}
              >
                <IoMdRefresh
                  className={`${match ? 'text-primary-foreground' : 'text-foreground'} text-[24px] ${restarting ? 'animate-spin' : ''}`}
                />
              </Button>
            </div>
          </CardBody>
          <CardFooter className="pt-1">
            <h3
              className={`text-md font-bold text-ellipsis whitespace-nowrap overflow-hidden ${match ? 'text-primary-foreground' : 'text-foreground'}`}
            >
              {t('sider.cards.core')}
            </h3>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}

export default MihomoCoreCard
